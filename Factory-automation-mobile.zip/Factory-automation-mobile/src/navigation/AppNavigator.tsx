import React, { useEffect, useState } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  Modal,
  FlatList,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import {
  createDrawerNavigator,
  DrawerContentScrollView,
  DrawerItem,
} from '@react-navigation/drawer';
import { useAuth } from '../context/AuthContext';
import { useOrg } from '../context/OrgContext';
import { adminOrgAPI } from '../services/api';

// Screens
import LoginScreen from '../screens/auth/LoginScreen';
import SignupScreen from '../screens/auth/SignupScreen';
import ForgotPasswordScreen from '../screens/auth/ForgotPasswordScreen';
import DashboardScreen from '../screens/dashboard/DashboardScreen';
import GateGuardScreen from '../screens/gate/GateGuardScreen';
import SupervisorScreen from '../screens/production/SupervisorScreen';
import QualityControlScreen from '../screens/quality/QualityControlScreen';
import StoreGodownScreen from '../screens/store/StoreGodownScreen';
import SalesDashboardScreen from '../screens/sales/SalesDashboardScreen';
import UsersScreen from '../screens/settings/UsersScreen';
import OrganizationsScreen from '../screens/settings/OrganizationsScreen';
import SettingsScreen from '../screens/settings/SettingsScreen';
import SupportScreen from '../screens/settings/SupportScreen';
import FinanceDashboardScreen from '../screens/finance/FinanceDashboardScreen';

const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();

// Auth Stack Navigation
function AuthNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Signup" component={SignupScreen} />
      <Stack.Screen name="ForgotPassword" component={ForgotPasswordScreen} />
    </Stack.Navigator>
  );
}

// Custom Drawer Content with Role Filters and Platform Admin Org Selector
function CustomDrawerContent(props: any) {
  const { user, logout } = useAuth();
  const { settings, colors, selectedOrgId, setSelectedOrgId } = useOrg();
  const [orgs, setOrgs] = useState<any[]>([]);
  const [showOrgSelector, setShowOrgSelector] = useState(false);

  const isPlatformAdmin =
    user?.role === 'super_admin' && user?.email === 'superadmin@trackbells.com';

  useEffect(() => {
    const fetchOrgs = async () => {
      if (isPlatformAdmin) {
        try {
          const res = await adminOrgAPI.getAll();
          if (res.data && res.data.success) {
            setOrgs(res.data.data);
          }
        } catch (e) {
          console.warn('Failed to fetch organizations for platform admin', e);
        }
      }
    };
    fetchOrgs();
  }, [isPlatformAdmin]);

  // Determine active organization name
  const currentOrgName =
    orgs.find((o) => o._id === selectedOrgId)?.name ||
    settings.brandName ||
    'TrackBells ERP';

  // Filter drawer items based on user role
  const drawerItems = settings.menus.filter(
    (menu) =>
      menu.visible &&
      (menu.roles.includes(user?.role || '') || user?.role === 'super_admin')
  );

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      {/* Header Profile / Org Logo */}
      <View style={[styles.drawerHeader, { borderBottomColor: colors.border }]}>
        <Image
          source={require('../assets/logo.png')}
          style={styles.logo}
          resizeMode="contain"
          defaultSource={require('../assets/logo_placeholder.png')}
        />
        <Text style={[styles.orgName, { color: colors.text }]}>{currentOrgName}</Text>
        <Text style={[styles.userName, { color: colors.textSecondary }]}>
          {user?.name || 'User'} ({user?.role ? user.role.toUpperCase() : ''})
        </Text>

        {/* Platform Admin Org Selection Trigger */}
        {isPlatformAdmin && (
          <TouchableOpacity
            style={[styles.orgSelectorBtn, { borderColor: colors.primary }]}
            onPress={() => setShowOrgSelector(true)}
          >
            <Text style={[styles.orgSelectorText, { color: colors.primary }]}>
              🏢 Change tenant
            </Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Drawer Menu Items */}
      <DrawerContentScrollView {...props}>
        <DrawerItem
          label="Dashboard"
          labelStyle={{ fontWeight: '700', color: colors.text }}
          onPress={() => props.navigation.navigate('Dashboard')}
          icon={() => <Text style={styles.menuIcon}>📊</Text>}
        />
        {(user?.role === 'super_admin' || user?.role === 'admin') && (
          <DrawerItem
            label="Finance & Purchase"
            labelStyle={{ fontWeight: '600', color: colors.textSecondary }}
            onPress={() => props.navigation.navigate('Finance')}
            icon={() => <Text style={styles.menuIcon}>💰</Text>}
          />
        )}
        {drawerItems.map((item) => (
          <DrawerItem
            key={item.key}
            label={item.label}
            labelStyle={{ fontWeight: '600', color: colors.textSecondary }}
            onPress={() => props.navigation.navigate(item.path)}
            icon={() => (
              <Text style={styles.menuIcon}>
                {item.key === 'gateGuard'
                  ? '🚛'
                  : item.key === 'supervisor'
                  ? '⚙️'
                  : item.key === 'qualityChecker'
                  ? '✅'
                  : item.key === 'storeManager'
                  ? '📦'
                  : item.key === 'sales'
                  ? '🛒'
                  : item.key === 'users'
                  ? '👥'
                  : item.key === 'settings'
                  ? '🔧'
                  : '📂'}
              </Text>
            )}
          />
        ))}
      </DrawerContentScrollView>

      {/* Footer / Sign Out */}
      <View style={[styles.drawerFooter, { borderTopColor: colors.border }]}>
        <TouchableOpacity style={styles.logoutBtn} onPress={logout}>
          <Text style={styles.logoutText}>🚪 Sign Out</Text>
        </TouchableOpacity>
        <Text style={[styles.footerText, { color: colors.textGhost }]}>
          {settings.footerText}
        </Text>
      </View>

      {/* Organization Switcher Modal for Platform Admin */}
      <Modal visible={showOrgSelector} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Choose SaaS Tenant</Text>
            <FlatList
              data={[{ _id: '', name: 'Default Organization' }, ...orgs]}
              keyExtractor={(item) => item._id}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={[
                    styles.orgSelectItem,
                    {
                      backgroundColor:
                        selectedOrgId === item._id || (!selectedOrgId && !item._id)
                          ? colors.primaryGlow
                          : 'transparent',
                    },
                  ]}
                  onPress={() => {
                    setSelectedOrgId(item._id || null);
                    setShowOrgSelector(false);
                  }}
                >
                  <Text
                    style={[
                      styles.orgSelectItemText,
                      {
                        color:
                          selectedOrgId === item._id || (!selectedOrgId && !item._id)
                            ? colors.primary
                            : colors.text,
                        fontWeight:
                          selectedOrgId === item._id || (!selectedOrgId && !item._id)
                            ? '700'
                            : '400',
                      },
                    ]}
                  >
                    {item.name}
                  </Text>
                </TouchableOpacity>
              )}
            />
            <TouchableOpacity
              style={[styles.closeBtn, { backgroundColor: colors.border }]}
              onPress={() => setShowOrgSelector(false)}
            >
              <Text style={{ color: colors.textSecondary, fontWeight: '600' }}>
                Cancel
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

// App Drawer Navigator Shell
function AppDrawer() {
  const { colors } = useOrg();
  return (
    <Drawer.Navigator
      drawerContent={(props) => <CustomDrawerContent {...props} />}
      screenOptions={{
        headerTintColor: colors.primary,
        headerStyle: {
          backgroundColor: '#ffffff',
          elevation: 1,
          shadowOpacity: 0.1,
        },
        drawerStyle: {
          width: 280,
        },
      }}
    >
      <Drawer.Screen name="Dashboard" component={DashboardScreen} />
      <Drawer.Screen name="GateGuard" component={GateGuardScreen} options={{ title: 'Gate Operations' }} />
      <Drawer.Screen name="Supervisor" component={SupervisorScreen} options={{ title: 'Production Line' }} />
      <Drawer.Screen name="Quality" component={QualityControlScreen} options={{ title: 'Quality Control' }} />
      <Drawer.Screen name="Store" component={StoreGodownScreen} options={{ title: 'Store & Godown' }} />
      <Drawer.Screen name="Sales" component={SalesDashboardScreen} options={{ title: 'Sales & Orders' }} />
      <Drawer.Screen name="Users" component={UsersScreen} options={{ title: 'User Management' }} />
      <Drawer.Screen name="Organizations" component={OrganizationsScreen} options={{ title: 'SaaS Tenants' }} />
      <Drawer.Screen name="Settings" component={SettingsScreen} options={{ title: 'Settings' }} />
      <Drawer.Screen name="Support" component={SupportScreen} options={{ title: 'Help & Support' }} />
      <Drawer.Screen name="Finance" component={FinanceDashboardScreen} options={{ title: 'Finance & Purchase' }} />
    </Drawer.Navigator>
  );
}

// Root Navigator Switcher
export default function AppNavigator() {
  const { isAuthenticated, loading } = useAuth();
  const { colors } = useOrg();

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {isAuthenticated ? (
          <Stack.Screen name="App" component={AppDrawer} />
        ) : (
          <Stack.Screen name="Auth" component={AuthNavigator} />
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  drawerHeader: {
    padding: 20,
    borderBottomWidth: 1,
    alignItems: 'flex-start',
  },
  logo: {
    height: 50,
    width: 140,
    marginBottom: 12,
  },
  orgName: {
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 4,
  },
  userName: {
    fontSize: 13,
    marginBottom: 10,
  },
  orgSelectorBtn: {
    borderWidth: 1,
    borderRadius: 6,
    paddingVertical: 4,
    paddingHorizontal: 8,
    marginTop: 4,
  },
  orgSelectorText: {
    fontSize: 12,
    fontWeight: '600',
  },
  menuIcon: {
    fontSize: 20,
    marginRight: -10,
  },
  drawerFooter: {
    padding: 20,
    borderTopWidth: 1,
  },
  logoutBtn: {
    paddingVertical: 10,
    marginBottom: 10,
  },
  logoutText: {
    color: '#d93025',
    fontWeight: '700',
    fontSize: 15,
  },
  footerText: {
    fontSize: 10,
    textAlign: 'center',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    padding: 24,
  },
  modalContent: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 24,
    maxHeight: '75%',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 16,
    textAlign: 'center',
  },
  orgSelectItem: {
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: 8,
    marginBottom: 8,
  },
  orgSelectItemText: {
    fontSize: 15,
  },
  closeBtn: {
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 16,
  },
});
