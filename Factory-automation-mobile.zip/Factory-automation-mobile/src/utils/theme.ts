import { StyleSheet } from 'react-native';

export interface ThemeColors {
  primary: string;
  primaryDark: string;
  primaryLight: string;
  primaryGlow: string;
  background: string;
  card: string;
  cardHover: string;
  input: string;
  text: string;
  textSecondary: string;
  textMuted: string;
  textGhost: string;
  border: string;
  borderLight: string;
  success: string;
  warning: string;
  danger: string;
  info: string;
}

export const defaultColors: ThemeColors = {
  primary: '#f97316',
  primaryDark: '#ea580c',
  primaryLight: '#fdba74',
  primaryGlow: 'rgba(249, 115, 22, 0.08)',
  background: '#f8fafc',
  card: '#ffffff',
  cardHover: '#f1f5f9',
  input: '#f8fafc',
  text: '#0f172a',
  textSecondary: '#334155',
  textMuted: '#64748b',
  textGhost: '#94a3b8',
  border: '#e2e8f0',
  borderLight: '#f1f5f9',
  success: '#1e8e3e',
  warning: '#ea580c',
  danger: '#d93025',
  info: '#00acc1',
};

// Functions to dynamically darken/lighten hex colors
export const darkenColor = (hex: string, percent: number): string => {
  try {
    let num = parseInt(hex.replace('#', ''), 16),
      amt = Math.round(2.55 * percent),
      R = (num >> 16) - amt,
      G = ((num >> 8) & 0x00ff) - amt,
      B = (num & 0x0000ff) - amt;
    return (
      '#' +
      (
        0x1000000 +
        (R < 255 ? (R < 0 ? 0 : R) : 255) * 0x10000 +
        (G < 255 ? (G < 0 ? 0 : G) : 255) * 0x100 +
        (B < 255 ? (B < 0 ? 0 : B) : 255)
      )
        .toString(16)
        .slice(1)
    );
  } catch (e) {
    console.warn(e);
    return hex;
  }
};

export const lightenColor = (hex: string, percent: number): string => {
  try {
    let num = parseInt(hex.replace('#', ''), 16),
      amt = Math.round(2.55 * percent),
      R = (num >> 16) + amt,
      G = ((num >> 8) & 0x00ff) + amt,
      B = (num & 0x0000ff) + amt;
    return (
      '#' +
      (
        0x1000000 +
        (R < 255 ? (R < 0 ? 0 : R) : 255) * 0x10000 +
        (G < 255 ? (G < 0 ? 0 : G) : 255) * 0x100 +
        (B < 255 ? (B < 0 ? 0 : B) : 255)
      )
        .toString(16)
        .slice(1)
    );
  } catch (e) {
    console.warn(e);
    return hex;
  }
};

export const getThemeColors = (primaryColor?: string): ThemeColors => {
  if (!primaryColor) return defaultColors;
  const dark = darkenColor(primaryColor, 10);
  const light = lightenColor(primaryColor, 30);
  return {
    ...defaultColors,
    primary: primaryColor,
    primaryDark: dark,
    primaryLight: light,
    primaryGlow: `${primaryColor}14`, // ~8% opacity hex suffix
  };
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
};

export const borderRadius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  full: 9999,
};

export const globalStyles = StyleSheet.create({
  flex1: {
    flex: 1,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  rowBetween: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: borderRadius.md,
    padding: spacing.lg,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    shadowColor: '#0f172a',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  shadow: {
    shadowColor: '#0f172a',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 6,
    elevation: 3,
  },
  glassmorphism: {
    backgroundColor: 'rgba(255, 255, 255, 0.85)',
    borderWidth: 1,
    borderColor: 'rgba(249, 115, 22, 0.15)',
  },
});
