import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const API_BASE_URL = 'https://trackbells.com/api';

const API = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 15000,
});

// Request interceptor - attach token and selected organization
API.interceptors.request.use(
  async (config) => {
    const token = await AsyncStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    const selectedOrgId = await AsyncStorage.getItem('selectedOrgId');
    if (selectedOrgId) {
      config.headers['X-Organization-Id'] = selectedOrgId;
    }
    if (config.data instanceof FormData) {
      delete config.headers['Content-Type'];
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor - handle 401 and 403
let onUnauthorizedCallback: (() => void) | null = null;
let onReverificationRequiredCallback: (() => void) | null = null;

export const setAuthCallbacks = (
  onUnauthorized: () => void,
  onReverificationRequired: () => void
) => {
  onUnauthorizedCallback = onUnauthorized;
  onReverificationRequiredCallback = onReverificationRequired;
};

API.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response) {
      if (error.response.status === 401) {
        await AsyncStorage.removeItem('token');
        await AsyncStorage.removeItem('user');
        if (onUnauthorizedCallback) {
          onUnauthorizedCallback();
        }
      }
      if (
        error.response.status === 403 &&
        error.response.data?.requiresReverification
      ) {
        if (onReverificationRequiredCallback) {
          onReverificationRequiredCallback();
        }
      }
    }
    return Promise.reject(error);
  }
);

// Auth API calls
export const authAPI = {
  register: (data: any) => API.post('/auth/register', data),
  login: (data: any) => API.post('/auth/login', data),
  logout: () => API.post('/auth/logout'),
  getMe: () => API.get('/auth/me'),
  forgotPassword: (email: string) => API.post('/auth/forgot-password', { email }),
  resetPassword: (token: string, password: string) =>
    API.put(`/auth/reset-password/${token}`, { password }),
  updateProfile: (data: any) => API.put('/auth/update-profile', data),
  changePassword: (data: any) => API.put('/auth/change-password', data),
  onboardSendOTP: (data: any) => API.post('/auth/onboard/send-otp', data),
  onboardVerifyOrg: (data: any) => API.post('/auth/onboard/verify-org', data),
};

// Gate Entry API calls
export const gateEntryAPI = {
  getAll: (params?: any) => API.get('/gate-entry', { params }),
  getById: (id: string) => API.get(`/gate-entry/${id}`),
  create: (data: any) => API.post('/gate-entry', data),
  update: (id: string, data: any) => API.put(`/gate-entry/${id}`, data),
  delete: (id: string) => API.delete(`/gate-entry/${id}`),
  verify: (id: string, data: any = {}) => API.put(`/gate-entry/${id}/verify`, data),
  createGRN: (id: string, data: any) => API.put(`/gate-entry/${id}/create-grn`, data),
  getStats: () => API.get('/gate-entry/stats'),
};

// Admin API calls
export const adminAPI = {
  getUsers: (params?: any) => API.get('/admin/users', { params }),
  getUser: (id: string) => API.get(`/admin/users/${id}`),
  createUser: (data: any) => API.post('/admin/users', data),
  updateUser: (id: string, data: any) => API.put(`/admin/users/${id}`, data),
  updateRole: (id: string, role: string) => API.put(`/admin/users/${id}/role`, { role }),
  toggleStatus: (id: string) => API.put(`/admin/users/${id}/status`),
  deleteUser: (id: string) => API.delete(`/admin/users/${id}`),
  getStats: () => API.get('/admin/stats'),
  getSuperStats: () => API.get('/admin/super-stats'),
};

// Production API calls
export const productionAPI = {
  createPlan: (data: any) => API.post('/production/plans', data),
  getPlans: (params?: any) => API.get('/production/plans', { params }),
  createWipBatch: (data: any) => API.post('/production/wip', data),
  getWipBatches: (params?: any) => API.get('/production/wip', { params }),
  updateWipStage: (id: string, data: any) => API.put(`/production/wip/${id}/stage`, data),
  getStats: () => API.get('/production/stats'),
};

// Store & Assembly API calls
export const storeAPI = {
  getReadyWip: () => API.get('/store/ready-wip'),
  assembleWip: (data: any) => API.post('/store/assemble', data),
  getAssemblies: () => API.get('/store/assemblies'),
  getRacks: () => API.get('/store/racks'),
  createRack: (data: any) => API.post('/store/racks', data),
  storeChain: (data: any) => API.post('/store/store-chain', data),
  getInventory: () => API.get('/store/inventory'),
  getStats: () => API.get('/store/stats'),
  saveScannedItems: (data: any) => API.post('/store/inventory/scan', data),
};

// Order Management API calls
export const orderAPI = {
  createOrder: (data: any) => API.post('/orders', data),
  getOrders: () => API.get('/orders'),
  getShortages: () => API.get('/orders/shortages'),
  planShortage: (id: string, data: any) => API.post(`/orders/shortages/${id}/plan`, data),
  dispatchOrder: (id: string) => API.post(`/orders/${id}/dispatch`),
  getStats: () => API.get('/orders/stats'),
};

// AI & Reports API calls
export const aiAPI = {
  predictShots: (data: any) => API.post('/ai/predict-shots', data),
  getReports: () => API.get('/ai/reports'),
  chatWithAI: (data: any) => API.post('/ai/chat', data),
};

// HR & Payroll API calls
export const hrAPI = {
  getStats: () => API.get('/hr/stats'),
  getEmployees: () => API.get('/hr/employees'),
  addEmployee: (data: any) => API.post('/hr/employees', data),
  punchAttendance: (data: any) => API.post('/hr/attendance', data),
  getAttendance: (date: string) => API.get(`/hr/attendance?date=${date}`),
  generatePayroll: (data: any) => API.post('/hr/payroll/generate', data),
  getPayroll: (month: number, year: number) =>
    API.get(`/hr/payroll?month=${month}&year=${year}`),
};

// Finance & OCR API calls
export const financeAPI = {
  getVendors: () => API.get('/finance/vendors'),
  addVendor: (data: any) => API.post('/finance/vendors', data),
  getPOs: () => API.get('/finance/pos'),
  createPO: (data: any) => API.post('/finance/pos', data),
  scanInvoice: (formData: FormData) =>
    API.post('/finance/scan-invoice', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }),
  getInvoices: () => API.get('/finance/invoices'),
};

// Notification API calls
export const notificationAPI = {
  getNotifications: () => API.get('/notifications'),
  markAsRead: (id: string) => API.put(`/notifications/${id}/read`),
  markAllAsRead: () => API.put('/notifications/read-all'),
};

// Admin Organizations API calls (Super Admin Only)
export const adminOrgAPI = {
  getAll: () => API.get('/organizations'),
  create: (data: any) => API.post('/organizations', data),
  approve: (id: string) => API.put(`/organizations/${id}/approve`),
  decline: (id: string, remark: string) =>
    API.put(`/organizations/${id}/decline`, { remark }),
  forceReverify: (id: string) => API.post(`/organizations/${id}/force-reverify`),
  reverifyOTP: (data: any) => API.post('/organizations/reverify-otp', data),
  resendReverifyOTP: () => API.post('/organizations/resend-reverify-otp'),
  getSettings: (params?: any) => API.get('/organizations/settings', { params }),
  updateSettings: (data: any) => API.put('/organizations/settings', data),
};

// Operations & Unified ERP API calls
export const operationsAPI = {
  // Inventory
  getInventory: () => API.get('/operations/inventory'),
  createInventoryItem: (data: any) => API.post('/operations/inventory', data),
  updateInventoryItem: (id: string, data: any) =>
    API.put(`/operations/inventory/${id}`, data),
  deleteInventoryItem: (id: string) => API.delete(`/operations/inventory/${id}`),

  // Machines
  getMachines: () => API.get('/operations/machines'),
  createMachine: (data: any) => API.post('/operations/machines', data),
  updateMachine: (id: string, data: any) =>
    API.put(`/operations/machines/${id}`, data),
  deleteMachine: (id: string) => API.delete(`/operations/machines/${id}`),

  // Build Jobs
  getBuildJobs: () => API.get('/operations/build-jobs'),
  createBuildJob: (data: any) => API.post('/operations/build-jobs', data),
  updateBuildJob: (id: string, data: any) =>
    API.put(`/operations/build-jobs/${id}`, data),
  sendToStore: (id: string) => API.put(`/operations/build-jobs/${id}/send-to-store`),
  receiveProduct: (id: string, data: any) =>
    API.put(`/operations/build-jobs/${id}/receive`, data),

  // Quality Logs
  getQualityLogs: () => API.get('/operations/qc-logs'),
  createQualityLog: (data: any) => API.post('/operations/qc-logs', data),
  updateQualityLog: (id: string, data: any) =>
    API.put(`/operations/qc-logs/${id}`, data),
  deleteQualityLog: (id: string) => API.delete(`/operations/qc-logs/${id}`),
  verifyQualityLog: (id: string) => API.put(`/operations/qc-logs/${id}/verify`),

  // Shortage, Buy & Sales Log
  getShortageBuySales: () => API.get('/operations/shortage-buy-sales'),
  createShortageBuySale: (data: any) => API.post('/operations/shortage-buy-sales', data),
  updateShortageBuySale: (id: string, data: any) =>
    API.put(`/operations/shortage-buy-sales/${id}`, data),
  deleteShortageBuySale: (id: string) =>
    API.delete(`/operations/shortage-buy-sales/${id}`),
};

export default API;
