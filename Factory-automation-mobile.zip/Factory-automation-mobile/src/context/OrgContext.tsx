import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { adminOrgAPI } from '../services/api';
import { useAuth } from './AuthContext';
import { defaultColors, getThemeColors, ThemeColors } from '../utils/theme';

export interface OrgMenu {
  key: string;
  label: string;
  icon: string;
  path: string;
  visible: boolean;
  roles: string[];
}

export interface OrgSettings {
  brandName: string;
  brandSubtitle: string;
  logo: string;
  themeColor: string;
  footerText: string;
  menus: OrgMenu[];
}

interface OrgContextType {
  settings: OrgSettings;
  colors: ThemeColors;
  loading: boolean;
  reloadSettings: () => Promise<void>;
  updateSettings: (newSettings: any) => Promise<OrgSettings>;
  selectedOrgId: string | null;
  setSelectedOrgId: (orgId: string | null) => Promise<void>;
}

const OrgContext = createContext<OrgContextType | null>(null);

export const useOrg = () => {
  const context = useContext(OrgContext);
  if (!context) {
    throw new Error('useOrg must be used within an OrgProvider');
  }
  return context;
};

const defaultSettings: OrgSettings = {
  brandName: 'TrackBells ERP',
  brandSubtitle: 'Factory Automation',
  logo: '/logo.png',
  themeColor: '#f97316',
  footerText: 'Powered by Cyberbells ITES services pvt ltd',
  menus: [
    { key: 'gateGuard', label: 'Gate Operations', icon: 'truck', path: 'GateGuard', visible: true, roles: ['super_admin', 'gate_guard'] },
    { key: 'supervisor', label: 'Production Line', icon: 'settings', path: 'Supervisor', visible: true, roles: ['super_admin', 'supervisor'] },
    { key: 'qualityChecker', label: 'Quality Control', icon: 'assignment-turned-in', path: 'Quality', visible: true, roles: ['super_admin', 'quality_checker'] },
    { key: 'storeManager', label: 'Store & Godown', icon: 'store', path: 'Store', visible: true, roles: ['super_admin', 'store_manager'] },
    { key: 'sales', label: 'Sales & Orders', icon: 'shopping-cart', path: 'Sales', visible: true, roles: ['super_admin', 'sales'] },
    { key: 'users', label: 'User Management', icon: 'people', path: 'Users', visible: true, roles: ['super_admin', 'admin'] },
    { key: 'optionalFeature', label: 'Optional Feature', icon: 'flash-on', path: 'OptionalFeature', visible: true, roles: ['super_admin', 'admin'] },
    { key: 'organizations', label: 'SaaS Tenants', icon: 'business', path: 'Organizations', visible: true, roles: ['super_admin'] },
    { key: 'settings', label: 'Settings', icon: 'tune', path: 'Settings', visible: true, roles: ['super_admin', 'admin'] },
    { key: 'support', label: 'Help & Support', icon: 'report', path: 'Support', visible: true, roles: ['super_admin'] }
  ]
};

export const OrgProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated, user } = useAuth();
  const [settings, setSettings] = useState<OrgSettings>(defaultSettings);
  const [colors, setColors] = useState<ThemeColors>(defaultColors);
  const [loading, setLoading] = useState(true);
  const [selectedOrgId, setSelectedOrgIdState] = useState<string | null>(null);

  useEffect(() => {
    const loadSelectedOrg = async () => {
      try {
        const storedOrgId = await AsyncStorage.getItem('selectedOrgId');
        setSelectedOrgIdState(storedOrgId);
      } catch (e) {
        console.error('Failed to load selectedOrgId from AsyncStorage', e);
      }
    };
    loadSelectedOrg();
  }, []);

  const setSelectedOrgId = async (orgId: string | null) => {
    try {
      if (orgId) {
        await AsyncStorage.setItem('selectedOrgId', orgId);
      } else {
        await AsyncStorage.removeItem('selectedOrgId');
      }
      setSelectedOrgIdState(orgId);
      // Reload settings with new org context headers
      if (isAuthenticated) {
        await fetchSettings();
      }
    } catch (e) {
      console.error('Failed to save selectedOrgId', e);
    }
  };

  const fetchSettings = async () => {
    try {
      const res = await adminOrgAPI.getSettings();
      if (res.data && res.data.success) {
        const orgData = res.data.data;
        if (orgData && orgData.logo === '🏭') {
          orgData.logo = '/logo.png';
        }
        setSettings(orgData);
        if (orgData.themeColor) {
          setColors(getThemeColors(orgData.themeColor));
        }
      }
    } catch (error) {
      console.error('Failed to fetch organization settings:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      fetchSettings();
    } else {
      setSettings(defaultSettings);
      setColors(defaultColors);
      setLoading(false);
    }
  }, [isAuthenticated, user?.organizationId]);

  const updateSettings = async (newSettings: any) => {
    const res = await adminOrgAPI.updateSettings(newSettings);
    if (res.data && res.data.success) {
      const updatedData = res.data.data;
      setSettings(updatedData);
      if (updatedData.themeColor) {
        setColors(getThemeColors(updatedData.themeColor));
      }
      return updatedData;
    }
    throw new Error('Failed to update organization settings');
  };

  return (
    <OrgContext.Provider
      value={{
        settings,
        colors,
        loading,
        reloadSettings: fetchSettings,
        updateSettings,
        selectedOrgId,
        setSelectedOrgId,
      }}
    >
      {children}
    </OrgContext.Provider>
  );
};
