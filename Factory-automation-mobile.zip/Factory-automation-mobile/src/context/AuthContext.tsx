import React, { createContext, useState, useContext, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { authAPI, setAuthCallbacks } from '../services/api';

export interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  organizationId: string;
  status: string;
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  loading: boolean;
  isAuthenticated: boolean;
  isReverificationRequired: boolean;
  setIsReverificationRequired: (req: boolean) => void;
  login: (email: string, password: string) => Promise<any>;
  signup: (data: any) => Promise<any>;
  logout: () => void;
  forgotPassword: (email: string) => Promise<any>;
  resetPassword: (token: string, password: string) => Promise<any>;
  setUser: React.Dispatch<React.SetStateAction<User | null>>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [isReverificationRequired, setIsReverificationRequired] = useState(false);

  // Set up API callbacks for automatic sign out on 401/403
  useEffect(() => {
    setAuthCallbacks(
      () => {
        // Unauthorized (401)
        setToken(null);
        setUser(null);
      },
      () => {
        // Reverification Required (403)
        setIsReverificationRequired(true);
      }
    );
  }, []);

  // Load user on mount if token exists in AsyncStorage
  useEffect(() => {
    const bootstrapAsync = async () => {
      let storedToken = null;
      let storedUser = null;
      try {
        storedToken = await AsyncStorage.getItem('token');
        const userStr = await AsyncStorage.getItem('user');
        storedUser = userStr ? JSON.parse(userStr) : null;
      } catch (e) {
        console.error('Failed to load auth credentials from storage', e);
      }

      if (storedToken) {
        setToken(storedToken);
        if (storedUser) {
          setUser(storedUser);
        }
        try {
          const res = await authAPI.getMe();
          if (res.data && res.data.user) {
            const freshUser = res.data.user;
            await AsyncStorage.setItem('user', JSON.stringify(freshUser));
            setUser(freshUser);
          }
        } catch (error: any) {
          console.error('Failed to verify token on bootstrap:', error);
          if (
            error.response &&
            error.response.status === 403 &&
            error.response.data?.requiresReverification
          ) {
            setIsReverificationRequired(true);
          } else {
            // Token expired or invalid, clear details
            await AsyncStorage.removeItem('token');
            await AsyncStorage.removeItem('user');
            setToken(null);
            setUser(null);
          }
        }
      }
      setLoading(false);
    };

    bootstrapAsync();
  }, []);

  const login = async (email: string, password: string) => {
    const res = await authAPI.login({ email, password });
    const { token: newToken, user: userData } = res.data;
    await AsyncStorage.setItem('token', newToken);
    await AsyncStorage.setItem('user', JSON.stringify(userData));
    setToken(newToken);
    setUser(userData);
    return res.data;
  };

  const signup = async (data: any) => {
    const res = await authAPI.register(data);
    return res.data;
  };

  const logout = async () => {
    try {
      await authAPI.logout();
    } catch (e) {
      console.warn('API logout failed', e);
    }
    await AsyncStorage.removeItem('token');
    await AsyncStorage.removeItem('user');
    setToken(null);
    setUser(null);
  };

  const forgotPassword = async (email: string) => {
    const res = await authAPI.forgotPassword(email);
    return res.data;
  };

  const resetPassword = async (resetToken: string, password: string) => {
    const res = await authAPI.resetPassword(resetToken, password);
    return res.data;
  };

  const value: AuthContextType = {
    user,
    token,
    loading,
    isAuthenticated: !!token && !!user,
    isReverificationRequired,
    setIsReverificationRequired,
    login,
    signup,
    logout,
    forgotPassword,
    resetPassword,
    setUser,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export default AuthContext;
