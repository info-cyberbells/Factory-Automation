import React from 'react';
import { StyleSheet, View, Text } from 'react-native';
import { useOrg } from '../../context/OrgContext';

export default function SettingsScreen() {
  const { colors } = useOrg();
  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <Text style={[styles.text, { color: colors.text }]}>Organization Settings</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: {
    fontSize: 18,
    fontWeight: '700',
  },
});
