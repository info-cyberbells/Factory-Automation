import React, { useEffect, useState, useCallback } from 'react';
import {
  StyleSheet,
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { useAuth } from '../../context/AuthContext';
import { useOrg } from '../../context/OrgContext';
import { gateEntryAPI, productionAPI, orderAPI, adminAPI } from '../../services/api';

export default function DashboardScreen({ navigation }: any) {
  const { user, logout } = useAuth();
  const { colors, settings } = useOrg();
  const [stats, setStats] = useState<any>({});
  const [loading, setLoading] = useState(false);

  const fetchStats = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      let data: any = {};
      
      // Fetch dynamic stats based on roles
      if (user.role === 'super_admin' || user.role === 'admin') {
        const adminRes = await adminAPI.getStats().catch(() => ({ data: {} }));
        data = { ...data, ...adminRes.data };
      }
      
      if (user.role === 'super_admin' || user.role === 'gate_guard') {
        const gateRes = await gateEntryAPI.getStats().catch(() => ({ data: {} }));
        data = { ...data, gate: gateRes.data };
      }

      if (user.role === 'super_admin' || user.role === 'supervisor') {
        const prodRes = await productionAPI.getStats().catch(() => ({ data: {} }));
        data = { ...data, production: prodRes.data };
      }

      if (user.role === 'super_admin' || user.role === 'sales') {
        const orderRes = await orderAPI.getStats().catch(() => ({ data: {} }));
        data = { ...data, orders: orderRes.data };
      }

      setStats(data);
    } catch (error) {
      console.warn('Failed to load dashboard statistics', error);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    fetchStats();
  }, [fetchStats]);

  // Determine active menus based on role
  const allowedMenus = settings.menus.filter(
    (menu) => menu.visible && (menu.roles.includes(user?.role || '') || user?.role === 'super_admin')
  );

  return (
    <ScrollView style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Welcome Banner */}
      <View style={[styles.welcomeBanner, { backgroundColor: colors.primary }]}>
        <View>
          <Text style={styles.welcomeTitle}>Hello, {user?.name || 'User'}</Text>
          <Text style={styles.welcomeSubtitle}>
            Role: {user?.role ? user.role.toUpperCase().replace('_', ' ') : 'Employee'}
          </Text>
        </View>
        <TouchableOpacity style={styles.logoutButton} onPress={logout}>
          <Text style={styles.logoutText}>Sign Out</Text>
        </TouchableOpacity>
      </View>

      {/* Main Content */}
      <View style={styles.content}>
        {/* Stats Row */}
        <Text style={[styles.sectionTitle, { color: colors.text }]}>Operations Summary</Text>
        {loading ? (
          <ActivityIndicator color={colors.primary} style={{ marginVertical: 20 }} />
        ) : (
          <View style={styles.statsGrid}>
            {user?.role === 'gate_guard' || user?.role === 'super_admin' ? (
              <View style={[styles.statCard, { borderColor: colors.border }]}>
                <Text style={[styles.statValue, { color: colors.primary }]}>
                  {stats.gate?.activeEntriesCount ?? stats.gate?.totalEntries ?? 0}
                </Text>
                <Text style={[styles.statLabel, { color: colors.textSecondary }]}>Active Vehicles</Text>
              </View>
            ) : null}

            {user?.role === 'supervisor' || user?.role === 'super_admin' ? (
              <View style={[styles.statCard, { borderColor: colors.border }]}>
                <Text style={[styles.statValue, { color: colors.primary }]}>
                  {stats.production?.activeWipCount ?? 0}
                </Text>
                <Text style={[styles.statLabel, { color: colors.textSecondary }]}>Active WIP Batches</Text>
              </View>
            ) : null}

            {user?.role === 'sales' || user?.role === 'super_admin' ? (
              <View style={[styles.statCard, { borderColor: colors.border }]}>
                <Text style={[styles.statValue, { color: colors.primary }]}>
                  {stats.orders?.pendingDispatchCount ?? stats.orders?.totalOrders ?? 0}
                </Text>
                <Text style={[styles.statLabel, { color: colors.textSecondary }]}>Pending Orders</Text>
              </View>
            ) : null}

            {user?.role === 'super_admin' || user?.role === 'admin' ? (
              <View style={[styles.statCard, { borderColor: colors.border }]}>
                <Text style={[styles.statValue, { color: colors.primary }]}>
                  {stats.totalUsers ?? 0}
                </Text>
                <Text style={[styles.statLabel, { color: colors.textSecondary }]}>Total Employees</Text>
              </View>
            ) : null}
          </View>
        )}

        {/* Quick Action Badges */}
        <Text style={[styles.sectionTitle, { color: colors.text, marginTop: 24 }]}>Quick Navigation</Text>
        <View style={styles.menuGrid}>
          {allowedMenus.map((menu) => (
            <TouchableOpacity
              key={menu.key}
              style={[styles.menuCard, { borderColor: colors.border }]}
              onPress={() => navigation.navigate(menu.path)}
            >
              <Text style={styles.menuIcon}>
                {menu.key === 'gateGuard'
                  ? '🚛'
                  : menu.key === 'supervisor'
                  ? '⚙️'
                  : menu.key === 'qualityChecker'
                  ? '✅'
                  : menu.key === 'storeManager'
                  ? '📦'
                  : menu.key === 'sales'
                  ? '🛒'
                  : menu.key === 'users'
                  ? '👥'
                  : menu.key === 'settings'
                  ? '🔧'
                  : '📂'}
              </Text>
              <Text style={[styles.menuLabel, { color: colors.text }]} numberOfLines={2}>
                {menu.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  welcomeBanner: {
    padding: 24,
    paddingTop: 32,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  welcomeTitle: {
    color: '#ffffff',
    fontSize: 22,
    fontWeight: '700',
    marginBottom: 4,
  },
  welcomeSubtitle: {
    color: 'rgba(255, 255, 255, 0.85)',
    fontSize: 14,
    fontWeight: '600',
  },
  logoutButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.25)',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  logoutText: {
    color: '#ffffff',
    fontSize: 13,
    fontWeight: '700',
  },
  content: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 17,
    fontWeight: '700',
    marginBottom: 16,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  statCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    shadowColor: '#0f172a',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 4,
    elevation: 1,
  },
  statValue: {
    fontSize: 24,
    fontWeight: '800',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    fontWeight: '600',
  },
  menuGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  menuCard: {
    width: '48%',
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
    marginBottom: 16,
    shadowColor: '#0f172a',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 4,
    elevation: 1,
  },
  menuIcon: {
    fontSize: 28,
    marginBottom: 12,
  },
  menuLabel: {
    fontSize: 14,
    fontWeight: '700',
    textAlign: 'center',
  },
});
