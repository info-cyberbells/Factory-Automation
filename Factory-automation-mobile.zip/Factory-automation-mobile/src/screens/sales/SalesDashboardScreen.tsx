import React, { useState, useEffect, useCallback } from 'react';
import {
  StyleSheet,
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
  Alert,
  FlatList,
  Modal,
  Linking,
} from 'react-native';
import { useOrg } from '../../context/OrgContext';
import { operationsAPI, orderAPI } from '../../services/api';

export default function SalesDashboardScreen() {
  const { colors } = useOrg();
  const [activeTab, setActiveTab] = useState<'stock' | 'sourcing' | 'place' | 'billing'>('stock');
  const [inventory, setInventory] = useState<any[]>([]);
  const [sbsLogs, setSbsLogs] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Form State for placing manufacturing order
  const [productName, setProductName] = useState('');
  const [productSize, setProductSize] = useState('');
  const [orderQuantity, setOrderQuantity] = useState('100');

  // Form State for creating a client sales order (Client Billing & SO)
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [orderItems, setOrderItems] = useState([{ name: '', quantity: '10', rate: '25' }]);
  const [selectedOrder, setSelectedOrder] = useState<any>(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      if (activeTab === 'stock') {
        const res = await operationsAPI.getInventory();
        setInventory(res.data.data);
      } else if (activeTab === 'sourcing') {
        const res = await operationsAPI.getShortageBuySales();
        setSbsLogs(res.data.data);
      } else if (activeTab === 'billing') {
        const res = await orderAPI.getOrders();
        setOrders(res.data.data);
      }
    } catch (err) {
      console.warn(err);
    } finally {
      setLoading(false);
    }
  }, [activeTab]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handlePlaceBuildOrder = async () => {
    if (!productName || !orderQuantity) {
      Alert.alert('Error', 'Please enter a product name and quantity');
      return;
    }
    setSubmitting(true);
    try {
      await operationsAPI.createBuildJob({
        productName,
        productSize,
        orderQuantity: parseFloat(orderQuantity),
      });
      Alert.alert('Success', 'Production order placed! Supervisor has been alerted.');
      setProductName('');
      setProductSize('');
      setOrderQuantity('100');
      setActiveTab('stock');
    } catch (err) {
      console.warn(err);
      Alert.alert('Error', 'Failed to place production order');
    } finally {
      setSubmitting(false);
    }
  };

  const handleCreateSalesOrder = async () => {
    if (!customerName || orderItems.some((item) => !item.name || !item.quantity)) {
      Alert.alert('Error', 'Please fill in customer name and item details');
      return;
    }
    setSubmitting(true);
    try {
      const items = orderItems.map((item) => ({
        itemName: item.name,
        quantity: parseFloat(item.quantity),
        rate: parseFloat(item.rate),
      }));
      const totalAmount = items.reduce((sum, item) => sum + item.quantity * item.rate, 0);

      await orderAPI.createOrder({
        customerName,
        items,
        totalAmount,
      });

      Alert.alert('Success', 'Sales Order created successfully!');
      setShowOrderModal(false);
      setCustomerName('');
      setOrderItems([{ name: '', quantity: '10', rate: '25' }]);
      fetchData();
    } catch (err) {
      console.warn(err);
      Alert.alert('Error', 'Failed to create Sales Order');
    } finally {
      setSubmitting(false);
    }
  };

  const handleOrderShortage = async (item: any) => {
    try {
      await operationsAPI.updateShortageBuySale(item._id, { status: 'ordered' });
      if (item.type === 'sale') {
        Alert.alert('Success', 'Sale registered successfully!');
      } else {
        Alert.alert('Success', 'Shortage raw materials ordered! Logged in pipeline.');
      }
      fetchData();
    } catch (err) {
      console.warn(err);
      Alert.alert('Error', item.type === 'sale' ? 'Failed to register sale' : 'Failed to order shortage items');
    }
  };

  const handleOpenPDF = (order: any) => {
    const url = `https://trackbells.com/api/orders/${order._id}/pdf`;
    Alert.alert('Invoice PDF', `Opening invoice for Order #${order.orderNumber || order._id.slice(-6)}`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Open in Browser', onPress: () => Linking.openURL(url) },
    ]);
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Scrollable Tabs */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tabScroll} contentContainerStyle={styles.tabContent}>
        {(['stock', 'sourcing', 'place', 'billing'] as const).map((tab) => (
          <TouchableOpacity
            key={tab}
            style={[
              styles.tab,
              activeTab === tab && { borderBottomColor: colors.primary, borderBottomWidth: 3 },
            ]}
            onPress={() => setActiveTab(tab)}
          >
            <Text
              style={[
                styles.tabText,
                { color: activeTab === tab ? colors.primary : colors.textSecondary },
              ]}
            >
              {tab === 'stock'
                ? 'Store Stock'
                : tab === 'sourcing'
                ? 'Sourcing / Sales'
                : tab === 'place'
                ? 'Place Order'
                : 'Billing & SO'}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Main Content */}
      <View style={styles.content}>
        {activeTab !== 'place' && (
          <View style={styles.headerActions}>
            <TextInput
              style={[styles.searchInput, { borderColor: colors.border, color: colors.text }]}
              placeholder="Search..."
              placeholderTextColor={colors.textGhost}
              value={search}
              onChangeText={setSearch}
            />
            {activeTab === 'billing' && (
              <TouchableOpacity
                style={[styles.addButton, { backgroundColor: colors.primary }]}
                onPress={() => setShowOrderModal(true)}
              >
                <Text style={styles.addButtonText}>New SO</Text>
              </TouchableOpacity>
            )}
          </View>
        )}

        {loading ? (
          <ActivityIndicator color={colors.primary} style={{ marginTop: 40 }} />
        ) : (
          <View style={{ flex: 1 }}>
            {activeTab === 'stock' && (
              <FlatList
                data={inventory.filter((i) => i.name.toLowerCase().includes(search.toLowerCase()))}
                keyExtractor={(item) => item._id}
                renderItem={({ item }) => (
                  <View style={[styles.card, { borderColor: colors.border }]}>
                    <View style={styles.cardHeader}>
                      <Text style={[styles.cardTitle, { color: colors.text }]}>{item.name}</Text>
                      <Text style={[styles.qtyText, { color: colors.primary }]}>
                        {item.quantity} {item.unit}
                      </Text>
                    </View>
                    <Text style={{ color: colors.textSecondary, fontSize: 13 }}>Type: {item.type.replace('_', ' ')}</Text>
                    <Text style={{ color: colors.textMuted, fontSize: 12 }}>Location: {item.location || 'N/A'}</Text>
                  </View>
                )}
                ListEmptyComponent={<Text style={styles.emptyText}>No matching inventory items</Text>}
              />
            )}

            {activeTab === 'sourcing' && (
              <FlatList
                data={sbsLogs.filter((i) => i.itemName.toLowerCase().includes(search.toLowerCase()))}
                keyExtractor={(item) => item._id}
                renderItem={({ item }) => (
                  <View style={[styles.card, { borderColor: colors.border }]}>
                    <View style={styles.cardHeader}>
                      <Text style={[styles.cardTitle, { color: colors.text }]}>{item.itemName}</Text>
                      <Text
                        style={[
                          styles.badge,
                          {
                            backgroundColor: item.type === 'sale' ? colors.primaryGlow : '#fee2e2',
                            color: item.type === 'sale' ? colors.primary : colors.danger,
                          },
                        ]}
                      >
                        {item.type.toUpperCase()}
                      </Text>
                    </View>
                    <Text style={{ color: colors.textSecondary, fontSize: 14 }}>
                      Quantity: {item.quantity} {item.unit}
                    </Text>
                    {item.remarks ? (
                      <Text style={{ color: colors.textMuted, fontSize: 12, marginTop: 4 }}>Note: {item.remarks}</Text>
                    ) : null}
                    
                    {item.status !== 'ordered' && item.status !== 'sold' && (
                      <TouchableOpacity
                        style={[styles.actionBtn, { backgroundColor: colors.primary }]}
                        onPress={() => handleOrderShortage(item)}
                      >
                        <Text style={styles.actionBtnText}>
                          {item.type === 'sale' ? 'Register Sale' : 'Order Material'}
                        </Text>
                      </TouchableOpacity>
                    )}
                    {(item.status === 'ordered' || item.status === 'sold') && (
                      <Text style={[styles.statusIndicator, { color: colors.success }]}>
                        Status: {item.status.toUpperCase()}
                      </Text>
                    )}
                  </View>
                )}
                ListEmptyComponent={<Text style={styles.emptyText}>No active sourcing logs</Text>}
              />
            )}

            {activeTab === 'place' && (
              <ScrollView keyboardShouldPersistTaps="handled">
                <Text style={[styles.sectionTitle, { color: colors.text }]}>Place Production/Mfg Order</Text>

                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Product Name *</Text>
                  <TextInput
                    style={[styles.input, { borderColor: colors.border, color: colors.text }]}
                    placeholder="e.g. Conveyor Belt Nylon-5"
                    value={productName}
                    onChangeText={setProductName}
                  />
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Size Spec (e.g. 500mm x 20m)</Text>
                  <TextInput
                    style={[styles.input, { borderColor: colors.border, color: colors.text }]}
                    placeholder="e.g. 600mm x 15m"
                    value={productSize}
                    onChangeText={setProductSize}
                  />
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Target Quantity (Units) *</Text>
                  <TextInput
                    style={[styles.input, { borderColor: colors.border, color: colors.text }]}
                    placeholder="100"
                    value={orderQuantity}
                    onChangeText={setOrderQuantity}
                    keyboardType="numeric"
                  />
                </View>

                <TouchableOpacity
                  style={[styles.submitButton, { backgroundColor: colors.primary }]}
                  onPress={handlePlaceBuildOrder}
                  disabled={submitting}
                >
                  {submitting ? (
                    <ActivityIndicator color="#ffffff" />
                  ) : (
                    <Text style={styles.submitButtonText}>Place Mfg Order</Text>
                  )}
                </TouchableOpacity>
              </ScrollView>
            )}

            {activeTab === 'billing' && (
              <FlatList
                data={orders.filter(
                  (o) =>
                    o.customerName.toLowerCase().includes(search.toLowerCase()) ||
                    (o.orderNumber && o.orderNumber.toString().includes(search))
                )}
                keyExtractor={(item) => item._id}
                renderItem={({ item }) => (
                  <View style={[styles.card, { borderColor: colors.border }]}>
                    <View style={styles.cardHeader}>
                      <Text style={[styles.cardTitle, { color: colors.text }]}>Order #{item.orderNumber || item._id.slice(-6)}</Text>
                      <Text style={{ color: colors.success, fontWeight: '700', fontSize: 16 }}>
                        ₹{item.totalAmount}
                      </Text>
                    </View>
                    <Text style={{ color: colors.textSecondary }}>Client: {item.customerName}</Text>
                    <Text style={{ color: colors.textMuted, fontSize: 12 }}>
                      Date: {new Date(item.createdAt).toLocaleDateString()}
                    </Text>

                    <View style={styles.billingActions}>
                      <TouchableOpacity style={styles.actionLink} onPress={() => setSelectedOrder(item)}>
                        <Text style={{ color: colors.primary, fontWeight: '700' }}>View Items</Text>
                      </TouchableOpacity>
                      <TouchableOpacity style={styles.actionLink} onPress={() => handleOpenPDF(item)}>
                        <Text style={{ color: colors.info, fontWeight: '700' }}>📄 Download SO PDF</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                )}
                ListEmptyComponent={<Text style={styles.emptyText}>No sales orders created yet</Text>}
              />
            )}
          </View>
        )}
      </View>

      {/* Customer Order Items Modal */}
      <Modal visible={selectedOrder !== null} animationType="fade" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>Order Details</Text>
            {selectedOrder && (
              <View>
                <Text style={{ fontWeight: '700', marginBottom: 4 }}>Client: {selectedOrder.customerName}</Text>
                <Text style={{ color: '#64748b', marginBottom: 12 }}>Date: {new Date(selectedOrder.createdAt).toLocaleString()}</Text>
                
                <Text style={{ fontWeight: '700', marginBottom: 8 }}>Items ordered:</Text>
                {selectedOrder.items?.map((item: any, idx: number) => (
                  <View key={idx} style={styles.orderItemRow}>
                    <Text style={{ flex: 2 }}>{item.itemName}</Text>
                    <Text style={{ flex: 1, textAlign: 'right' }}>{item.quantity} x ₹{item.rate}</Text>
                  </View>
                ))}
                
                <Text style={styles.totalSumText}>Total Amount: ₹{selectedOrder.totalAmount}</Text>
              </View>
            )}
            <TouchableOpacity
              style={[styles.closeBtn, { backgroundColor: colors.border }]}
              onPress={() => setSelectedOrder(null)}
            >
              <Text style={{ color: colors.textSecondary, fontWeight: '600' }}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* New SO Creator Modal */}
      <Modal visible={showOrderModal} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>Create Sales Order</Text>
            <ScrollView keyboardShouldPersistTaps="handled">
              <View style={styles.inputGroup}>
                <Text style={styles.label}>Customer / Client Name *</Text>
                <TextInput
                  style={[styles.input, { borderColor: colors.border, color: colors.text }]}
                  placeholder="e.g. Tata Motors"
                  value={customerName}
                  onChangeText={setCustomerName}
                />
              </View>

              <Text style={[styles.label, { marginTop: 8 }]}>Order Items:</Text>
              {orderItems.map((item, idx) => (
                <View key={idx} style={[styles.row, { alignItems: 'center', marginBottom: 10 }]}>
                  <TextInput
                    style={[styles.input, { flex: 2, marginRight: 6, borderColor: colors.border }]}
                    placeholder="Item name"
                    value={item.name}
                    onChangeText={(val) => {
                      const newItems = [...orderItems];
                      newItems[idx].name = val;
                      setOrderItems(newItems);
                    }}
                  />
                  <TextInput
                    style={[styles.input, { flex: 1, marginRight: 6, borderColor: colors.border }]}
                    placeholder="Qty"
                    keyboardType="numeric"
                    value={item.quantity}
                    onChangeText={(val) => {
                      const newItems = [...orderItems];
                      newItems[idx].quantity = val;
                      setOrderItems(newItems);
                    }}
                  />
                  <TextInput
                    style={[styles.input, { flex: 1, borderColor: colors.border }]}
                    placeholder="Rate"
                    keyboardType="numeric"
                    value={item.rate}
                    onChangeText={(val) => {
                      const newItems = [...orderItems];
                      newItems[idx].rate = val;
                      setOrderItems(newItems);
                    }}
                  />
                </View>
              ))}

              <TouchableOpacity
                onPress={() => setOrderItems([...orderItems, { name: '', quantity: '10', rate: '25' }])}
                style={{ paddingVertical: 8 }}
              >
                <Text style={{ color: colors.primary, fontWeight: '700' }}>+ Add Another Item</Text>
              </TouchableOpacity>

              <View style={styles.modalButtons}>
                <TouchableOpacity
                  style={[styles.cancelBtn, { borderColor: colors.border }]}
                  onPress={() => setShowOrderModal(false)}
                >
                  <Text style={{ color: colors.textSecondary, fontWeight: '600' }}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.submitBtn, { backgroundColor: colors.primary }]}
                  onPress={handleCreateSalesOrder}
                  disabled={submitting}
                >
                  {submitting ? (
                    <ActivityIndicator color="#ffffff" />
                  ) : (
                    <Text style={{ color: '#ffffff', fontWeight: '700' }}>Generate SO & Invoice</Text>
                  )}
                </TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  tabScroll: {
    maxHeight: 50,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  tabContent: {
    paddingHorizontal: 8,
  },
  tab: {
    paddingHorizontal: 16,
    paddingVertical: 14,
    alignItems: 'center',
  },
  tabText: {
    fontSize: 14,
    fontWeight: '700',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  searchInput: {
    flex: 1,
    borderWidth: 1,
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 12,
    backgroundColor: '#ffffff',
  },
  addButton: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  addButtonText: {
    color: '#ffffff',
    fontWeight: '700',
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    borderWidth: 1,
    padding: 16,
    marginBottom: 12,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  cardTitle: {
    fontSize: 15,
    fontWeight: '700',
  },
  qtyText: {
    fontSize: 15,
    fontWeight: '700',
  },
  badge: {
    fontSize: 10,
    fontWeight: '700',
    paddingVertical: 3,
    paddingHorizontal: 6,
    borderRadius: 8,
  },
  actionBtn: {
    paddingVertical: 8,
    borderRadius: 6,
    alignItems: 'center',
    marginTop: 10,
  },
  actionBtnText: {
    color: '#ffffff',
    fontWeight: '700',
    fontSize: 12,
  },
  statusIndicator: {
    fontSize: 13,
    fontWeight: '700',
    marginTop: 10,
  },
  sectionTitle: {
    fontSize: 17,
    fontWeight: '700',
    marginBottom: 16,
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 8,
    color: '#334155',
  },
  input: {
    borderWidth: 1,
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 12,
    fontSize: 15,
    backgroundColor: '#ffffff',
  },
  submitButton: {
    borderRadius: 8,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 12,
    marginBottom: 24,
  },
  submitButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '700',
  },
  billingActions: {
    flexDirection: 'row',
    gap: 16,
    marginTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
    paddingTop: 8,
  },
  actionLink: {
    paddingVertical: 4,
  },
  emptyText: {
    textAlign: 'center',
    marginTop: 40,
    color: '#64748b',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 24,
    maxHeight: '85%',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 16,
    textAlign: 'center',
  },
  orderItemRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 6,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  totalSumText: {
    fontWeight: '700',
    fontSize: 16,
    textAlign: 'right',
    marginTop: 16,
    color: '#10b981',
  },
  closeBtn: {
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 16,
  },
  row: {
    flexDirection: 'row',
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 16,
  },
  cancelBtn: {
    flex: 1,
    borderWidth: 1,
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: 'center',
  },
  submitBtn: {
    flex: 2,
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: 'center',
  },
});
