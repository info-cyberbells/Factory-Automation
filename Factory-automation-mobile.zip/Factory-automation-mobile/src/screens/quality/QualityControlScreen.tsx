import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
  Alert,
  FlatList,
  Modal,
} from 'react-native';
import { useOrg } from '../../context/OrgContext';
import { operationsAPI } from '../../services/api';

export default function QualityControlScreen() {
  const { colors } = useOrg();
  const [activeTab, setActiveTab] = useState<'inspected' | 'damaged' | 'missed' | 'invoice'>('inspected');
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Form State
  const [materialName, setMaterialName] = useState('');
  const [quantity, setQuantity] = useState('');
  const [unit, setUnit] = useState('pcs');
  const [remarks, setRemarks] = useState('');
  
  // Invoice specific fields
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [invoiceUrl, setInvoiceUrl] = useState('');

  const fetchLogs = async () => {
    setLoading(true);
    try {
      const res = await operationsAPI.getQualityLogs();
      setLogs(res.data.data);
    } catch (err) {
      console.warn(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  const handleSaveQC = async () => {
    if (!materialName || !quantity) {
      Alert.alert('Error', 'Please fill in item name and quantity');
      return;
    }
    setSubmitting(true);
    try {
      const payload: any = {
        materialName,
        quantity: parseFloat(quantity),
        unit,
        remarks,
        qcType: activeTab === 'invoice' ? 'inspected' : activeTab,
      };

      if (activeTab === 'invoice') {
        payload.invoiceNumber = invoiceNumber || `INV-${Date.now().toString().slice(-6)}`;
        payload.invoiceUrl = invoiceUrl || 'https://gcp.google.com/billing/mock-invoice.pdf';
      }

      await operationsAPI.createQualityLog(payload);
      Alert.alert('Success', 'Quality check report uploaded successfully!');
      setShowModal(false);
      
      // Reset Form
      setMaterialName('');
      setQuantity('');
      setUnit('pcs');
      setRemarks('');
      setInvoiceNumber('');
      setInvoiceUrl('');
      
      fetchLogs();
    } catch (err: any) {
      Alert.alert('Error', err.response?.data?.message || 'Failed to submit QC report');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteLog = async (id: string) => {
    Alert.alert('Confirm Delete', 'Are you sure you want to delete this log?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            await operationsAPI.deleteQualityLog(id);
            Alert.alert('Success', 'QC report log deleted');
            fetchLogs();
          } catch (err) {
            console.warn(err);
            Alert.alert('Error', 'Failed to delete report log');
          }
        },
      },
    ]);
  };

  const triggerMockUpload = () => {
    const mockUrls = [
      'https://microsoft.com/en-us/mock-invoice-10023.pdf',
      'https://gcp.google.com/billing/invoice-992381.pdf',
      'https://azure.microsoft.com/billing/inv-448821.pdf',
    ];
    const randUrl = mockUrls[Math.floor(Math.random() * mockUrls.length)];
    setInvoiceUrl(randUrl);
    setInvoiceNumber(`INV-${Math.floor(100000 + Math.random() * 900000)}`);
    Alert.alert('Success', 'Document uploaded & scanned via simulated OCR!');
  };

  const getFilteredLogs = () => {
    const targetType = activeTab === 'invoice' ? 'inspected' : activeTab;
    return logs.filter((log) => {
      const matchType = log.qcType === targetType;
      const matchSearch =
        log.materialName.toLowerCase().includes(search.toLowerCase()) ||
        (log.invoiceNumber && log.invoiceNumber.toLowerCase().includes(search.toLowerCase()));
      if (activeTab === 'invoice') {
        return matchType && matchSearch && log.invoiceNumber;
      }
      return matchType && matchSearch;
    });
  };

  const filteredLogs = getFilteredLogs();

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Scrollable Tabs */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tabScroll} contentContainerStyle={styles.tabContent}>
        {(['inspected', 'damaged', 'missed', 'invoice'] as const).map((tab) => (
          <TouchableOpacity
            key={tab}
            style={[
              styles.tab,
              activeTab === tab && { borderBottomColor: colors.primary, borderBottomWidth: 3 },
            ]}
            onPress={() => setActiveTab(tab)}
          >
            <Text
              style={[
                styles.tabText,
                { color: activeTab === tab ? colors.primary : colors.textSecondary },
              ]}
            >
              {tab === 'inspected'
                ? 'QC Goods'
                : tab === 'damaged'
                ? 'Damaged'
                : tab === 'missed'
                ? 'Shortage'
                : 'OCR Invoices'}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Main Content */}
      <View style={styles.content}>
        <View style={styles.headerActions}>
          <TextInput
            style={[styles.searchInput, { borderColor: colors.border, color: colors.text }]}
            placeholder="Search items or invoices..."
            placeholderTextColor={colors.textGhost}
            value={search}
            onChangeText={setSearch}
          />
          <TouchableOpacity
            style={[styles.addButton, { backgroundColor: colors.primary }]}
            onPress={() => setShowModal(true)}
          >
            <Text style={styles.addButtonText}>Add Log</Text>
          </TouchableOpacity>
        </View>

        {loading ? (
          <ActivityIndicator color={colors.primary} style={{ marginTop: 40 }} />
        ) : (
          <FlatList
            data={filteredLogs}
            keyExtractor={(item) => item._id}
            contentContainerStyle={styles.listPadding}
            renderItem={({ item }) => (
              <View style={[styles.card, { borderColor: colors.border }]}>
                <View style={styles.cardHeader}>
                  <Text style={[styles.cardTitle, { color: colors.text }]}>{item.materialName}</Text>
                  <Text style={[styles.qtyText, { color: colors.primary }]}>
                    {item.quantity} {item.unit}
                  </Text>
                </View>
                {item.invoiceNumber && (
                  <Text style={[styles.invoiceText, { color: colors.success }]}>
                    Invoice: {item.invoiceNumber}
                  </Text>
                )}
                {item.remarks ? (
                  <Text style={[styles.remarksText, { color: colors.textSecondary }]}>
                    Note: {item.remarks}
                  </Text>
                ) : null}
                <View style={styles.cardActions}>
                  <Text
                    style={[
                      styles.statusBadge,
                      {
                        backgroundColor:
                          item.status === 'verified'
                            ? '#e6f7ed'
                            : item.status === 'pending_verification'
                            ? '#fef3c7'
                            : '#fee2e2',
                        color:
                          item.status === 'verified'
                            ? colors.success
                            : item.status === 'pending_verification'
                            ? colors.warning
                            : colors.danger,
                      },
                    ]}
                  >
                    {item.status.toUpperCase().replace('_', ' ')}
                  </Text>
                  <TouchableOpacity onPress={() => handleDeleteLog(item._id)}>
                    <Text style={{ color: colors.danger, fontWeight: '700', fontSize: 13 }}>
                      Delete
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}
            ListEmptyComponent={<Text style={styles.emptyText}>No quality logs found</Text>}
          />
        )}
      </View>

      {/* Log Add Modal */}
      <Modal visible={showModal} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>
              {activeTab === 'invoice' ? 'Upload Invoice Bill' : 'Add Inspection Record'}
            </Text>
            <ScrollView keyboardShouldPersistTaps="handled">
              <View style={styles.inputGroup}>
                <Text style={styles.label}>Material / Item Name *</Text>
                <TextInput
                  style={[styles.input, { borderColor: colors.border, color: colors.text }]}
                  placeholder="e.g. Nylon Roll"
                  value={materialName}
                  onChangeText={setMaterialName}
                />
              </View>

              <View style={styles.row}>
                <View style={[styles.inputGroup, { flex: 2, marginRight: 8 }]}>
                  <Text style={styles.label}>Quantity *</Text>
                  <TextInput
                    style={[styles.input, { borderColor: colors.border, color: colors.text }]}
                    placeholder="0"
                    value={quantity}
                    onChangeText={setQuantity}
                    keyboardType="numeric"
                  />
                </View>
                <View style={[styles.inputGroup, { flex: 1 }]}>
                  <Text style={styles.label}>Unit</Text>
                  <TextInput
                    style={[styles.input, { borderColor: colors.border, color: colors.text }]}
                    placeholder="pcs/kg"
                    value={unit}
                    onChangeText={setUnit}
                  />
                </View>
              </View>

              {activeTab === 'invoice' && (
                <View style={styles.inputGroup}>
                  <Text style={styles.label}>OCR Scanner Document</Text>
                  <TouchableOpacity
                    style={[styles.uploadButton, { borderColor: colors.primary }]}
                    onPress={triggerMockUpload}
                  >
                    <Text style={{ color: colors.primary, fontWeight: '700' }}>
                      {invoiceNumber ? `Scanned: ${invoiceNumber}` : '📸 Capture & Extract details'}
                    </Text>
                  </TouchableOpacity>
                </View>
              )}

              <View style={styles.inputGroup}>
                <Text style={styles.label}>Remarks / Inspection notes</Text>
                <TextInput
                  style={[styles.input, styles.textArea, { borderColor: colors.border, color: colors.text }]}
                  placeholder="Defects or remarks..."
                  value={remarks}
                  onChangeText={setRemarks}
                  multiline
                  numberOfLines={3}
                />
              </View>

              <View style={styles.modalButtons}>
                <TouchableOpacity
                  style={[styles.cancelBtn, { borderColor: colors.border }]}
                  onPress={() => setShowModal(false)}
                >
                  <Text style={{ color: colors.textSecondary, fontWeight: '600' }}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.submitBtn, { backgroundColor: colors.primary }]}
                  onPress={handleSaveQC}
                  disabled={submitting}
                >
                  {submitting ? (
                    <ActivityIndicator color="#ffffff" />
                  ) : (
                    <Text style={{ color: '#ffffff', fontWeight: '700' }}>Submit Record</Text>
                  )}
                </TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  tabScroll: {
    maxHeight: 50,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  tabContent: {
    paddingHorizontal: 8,
  },
  tab: {
    paddingHorizontal: 16,
    paddingVertical: 14,
    alignItems: 'center',
  },
  tabText: {
    fontSize: 14,
    fontWeight: '700',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  searchInput: {
    flex: 1,
    borderWidth: 1,
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 12,
    backgroundColor: '#ffffff',
  },
  addButton: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  addButtonText: {
    color: '#ffffff',
    fontWeight: '700',
  },
  listPadding: {
    paddingBottom: 24,
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    borderWidth: 1,
    padding: 16,
    marginBottom: 12,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: '700',
  },
  qtyText: {
    fontSize: 15,
    fontWeight: '700',
  },
  invoiceText: {
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 4,
  },
  remarksText: {
    fontSize: 13,
    marginBottom: 10,
  },
  cardActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  statusBadge: {
    fontSize: 11,
    fontWeight: '700',
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 8,
  },
  emptyText: {
    textAlign: 'center',
    marginTop: 40,
    color: '#64748b',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 24,
    maxHeight: '85%',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 16,
    textAlign: 'center',
  },
  inputGroup: {
    marginBottom: 16,
  },
  row: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 8,
    color: '#334155',
  },
  input: {
    borderWidth: 1,
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 12,
    fontSize: 15,
    backgroundColor: '#ffffff',
  },
  uploadButton: {
    borderWidth: 1,
    borderStyle: 'dashed',
    borderRadius: 8,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top',
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 16,
  },
  cancelBtn: {
    flex: 1,
    borderWidth: 1,
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: 'center',
  },
  submitBtn: {
    flex: 2,
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: 'center',
  },
});
