import React, { useState, useEffect, useCallback } from 'react';
import {
  StyleSheet,
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
  Alert,
  FlatList,
} from 'react-native';
import { useOrg } from '../../context/OrgContext';
import { gateEntryAPI, operationsAPI, aiAPI } from '../../services/api';

export default function SupervisorScreen() {
  const { colors } = useOrg();
  const [activeTab, setActiveTab] = useState<'gate' | 'wip' | 'machines' | 'ai'>('gate');
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Data states
  const [gateEntries, setGateEntries] = useState<any[]>([]);
  const [buildJobs, setBuildJobs] = useState<any[]>([]);
  const [machines, setMachines] = useState<any[]>([]);

  // AI calculator inputs
  const [extrusionSpeed, setExtrusionSpeed] = useState('');
  const [density, setDensity] = useState('');
  const [thickness, setThickness] = useState('');
  const [width, setWidth] = useState('');
  const [aiResult, setAiResult] = useState<any>(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      if (activeTab === 'gate') {
        const res = await gateEntryAPI.getAll();
        setGateEntries(res.data.data.filter((e: any) => e.status !== 'verified'));
      } else if (activeTab === 'wip') {
        const res = await operationsAPI.getBuildJobs();
        setBuildJobs(res.data.data);
      } else if (activeTab === 'machines') {
        const res = await operationsAPI.getMachines();
        setMachines(res.data.data);
      }
    } catch (err) {
      console.warn(err);
    } finally {
      setLoading(false);
    }
  }, [activeTab]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleApproveGate = async (entryId: string, itemData: any) => {
    setSubmitting(true);
    try {
      // First create inventory item matching
      await operationsAPI.createInventoryItem({
        name: itemData.materialType ? itemData.materialType.charAt(0).toUpperCase() + itemData.materialType.slice(1) : 'Material',
        type: 'raw_material',
        quantity: itemData.quantity,
        unit: itemData.unit || 'kg',
        location: 'Main Store',
        description: itemData.materialDescription || 'Added via Gate Guard approval',
      });
      // Then verify gate entry
      await gateEntryAPI.verify(entryId);
      Alert.alert('Success', 'Gate Entry approved & inventory updated!');
      fetchData();
    } catch (err: any) {
      Alert.alert('Error', err.response?.data?.message || 'Verification failed');
    } finally {
      setSubmitting(false);
    }
  };

  const handleUpdateWipStage = async (jobId: string, currentStage: string) => {
    let nextStage = 'cutting';
    if (currentStage === 'extrusion') nextStage = 'cutting';
    else if (currentStage === 'cutting') nextStage = 'assembly';
    else if (currentStage === 'assembly') nextStage = 'completed';
    else return;

    setSubmitting(true);
    try {
      await operationsAPI.updateBuildJob(jobId, { status: nextStage });
      Alert.alert('Success', `Build Job updated to ${nextStage.toUpperCase()} stage!`);
      fetchData();
    } catch (err: any) {
      Alert.alert('Error', err.response?.data?.message || 'Stage transition failed');
    } finally {
      setSubmitting(false);
    }
  };

  const handlePredictShots = async () => {
    if (!extrusionSpeed || !density || !thickness || !width) {
      Alert.alert('Error', 'Please fill in all speed and dimension parameters');
      return;
    }
    setSubmitting(true);
    try {
      const res = await aiAPI.predictShots({
        extrusionSpeed: parseFloat(extrusionSpeed),
        density: parseFloat(density),
        thickness: parseFloat(thickness),
        width: parseFloat(width),
      });
      setAiResult(res.data);
    } catch (err: any) {
      Alert.alert('AI Prediction Failed', err.response?.data?.message || 'AI engine is currently unavailable.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Scrollable Tabs */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tabScroll} contentContainerStyle={styles.tabContent}>
        {(['gate', 'wip', 'machines', 'ai'] as const).map((tab) => (
          <TouchableOpacity
            key={tab}
            style={[
              styles.tab,
              activeTab === tab && { borderBottomColor: colors.primary, borderBottomWidth: 3 },
            ]}
            onPress={() => setActiveTab(tab)}
          >
            <Text
              style={[
                styles.tabText,
                { color: activeTab === tab ? colors.primary : colors.textSecondary },
              ]}
            >
              {tab === 'gate'
                ? 'Gate Approvals'
                : tab === 'wip'
                ? 'WIP Stages'
                : tab === 'machines'
                ? 'Machinery'
                : 'AI Shot Calc'}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {loading ? (
        <ActivityIndicator color={colors.primary} style={{ marginTop: 40 }} />
      ) : (
        <View style={{ flex: 1 }}>
          {activeTab === 'gate' && (
            <FlatList
              data={gateEntries}
              keyExtractor={(item) => item._id}
              contentContainerStyle={styles.listPadding}
              renderItem={({ item }) => (
                <View style={[styles.card, { borderColor: colors.border }]}>
                  <View style={styles.cardHeader}>
                    <Text style={[styles.cardTitle, { color: colors.text }]}>Bill: {item.billNumber}</Text>
                    <Text style={[styles.qtyText, { color: colors.primary }]}>{item.quantity} {item.unit}</Text>
                  </View>
                  <Text style={{ color: colors.textSecondary }}>Vendor: {item.vendorName}</Text>
                  <Text style={{ color: colors.textMuted, fontSize: 13 }}>Material: {item.materialType}</Text>
                  
                  <TouchableOpacity
                    style={[styles.actionBtn, { backgroundColor: colors.success }]}
                    onPress={() => handleApproveGate(item._id, item)}
                    disabled={submitting}
                  >
                    <Text style={styles.actionBtnText}>Approve & Move to Store</Text>
                  </TouchableOpacity>
                </View>
              )}
              ListEmptyComponent={<Text style={styles.emptyText}>No pending gate approvals</Text>}
            />
          )}

          {activeTab === 'wip' && (
            <FlatList
              data={buildJobs}
              keyExtractor={(item) => item._id}
              contentContainerStyle={styles.listPadding}
              renderItem={({ item }) => (
                <View style={[styles.card, { borderColor: colors.border }]}>
                  <View style={styles.cardHeader}>
                    <Text style={[styles.cardTitle, { color: colors.text }]}>{item.name || 'Build Job'}</Text>
                    <Text style={[styles.statusText, { color: colors.primary }]}>{item.status.toUpperCase()}</Text>
                  </View>
                  <Text style={{ color: colors.textSecondary }}>Target Qty: {item.targetQuantity} units</Text>
                  {item.machine && <Text style={{ color: colors.textMuted }}>Machine: {item.machine.name}</Text>}
                  
                  {item.status !== 'completed' && (
                    <TouchableOpacity
                      style={[styles.actionBtn, { backgroundColor: colors.primary }]}
                      onPress={() => handleUpdateWipStage(item._id, item.status)}
                      disabled={submitting}
                    >
                      <Text style={styles.actionBtnText}>
                        Move to {item.status === 'extrusion' ? 'CUTTING' : item.status === 'cutting' ? 'ASSEMBLY' : 'COMPLETED'}
                      </Text>
                    </TouchableOpacity>
                  )}
                </View>
              )}
              ListEmptyComponent={<Text style={styles.emptyText}>No active production jobs</Text>}
            />
          )}

          {activeTab === 'machines' && (
            <FlatList
              data={machines}
              keyExtractor={(item) => item._id}
              contentContainerStyle={styles.listPadding}
              renderItem={({ item }) => (
                <View style={[styles.card, { borderColor: colors.border }]}>
                  <View style={styles.cardHeader}>
                    <Text style={[styles.cardTitle, { color: colors.text }]}>{item.name}</Text>
                    <Text
                      style={[
                        styles.statusBadge,
                        {
                          backgroundColor: item.status === 'working' ? '#e6f7ed' : '#fef3c7',
                          color: item.status === 'working' ? colors.success : colors.warning,
                        },
                      ]}
                    >
                      {item.status.toUpperCase()}
                    </Text>
                  </View>
                  <Text style={{ color: colors.textSecondary }}>Capacity: {item.capacity || 'N/A'}</Text>
                  {item.remarks && <Text style={{ color: colors.textMuted, fontSize: 13 }}>Remarks: {item.remarks}</Text>}
                </View>
              )}
              ListEmptyComponent={<Text style={styles.emptyText}>No registered machinery found</Text>}
            />
          )}

          {activeTab === 'ai' && (
            <ScrollView contentContainerStyle={styles.formPadding} keyboardShouldPersistTaps="handled">
              <Text style={[styles.formTitle, { color: colors.text }]}>AI Extrusion Shot Calculator</Text>
              
              <View style={styles.inputGroup}>
                <Text style={[styles.label, { color: colors.textSecondary }]}>Extrusion Line Speed (m/min)</Text>
                <TextInput
                  style={[styles.input, { borderColor: colors.border, color: colors.text }]}
                  placeholder="e.g. 15.5"
                  value={extrusionSpeed}
                  onChangeText={setExtrusionSpeed}
                  keyboardType="numeric"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={[styles.label, { color: colors.textSecondary }]}>Material Density (g/cm³)</Text>
                <TextInput
                  style={[styles.input, { borderColor: colors.border, color: colors.text }]}
                  placeholder="e.g. 1.15"
                  value={density}
                  onChangeText={setDensity}
                  keyboardType="numeric"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={[styles.label, { color: colors.textSecondary }]}>Belt Thickness (mm)</Text>
                <TextInput
                  style={[styles.input, { borderColor: colors.border, color: colors.text }]}
                  placeholder="e.g. 3.2"
                  value={thickness}
                  onChangeText={setThickness}
                  keyboardType="numeric"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={[styles.label, { color: colors.textSecondary }]}>Belt Width (mm)</Text>
                <TextInput
                  style={[styles.input, { borderColor: colors.border, color: colors.text }]}
                  placeholder="e.g. 600"
                  value={width}
                  onChangeText={setWidth}
                  keyboardType="numeric"
                />
              </View>

              <TouchableOpacity
                style={[styles.predictBtn, { backgroundColor: colors.primary }]}
                onPress={handlePredictShots}
                disabled={submitting}
              >
                {submitting ? (
                  <ActivityIndicator color="#ffffff" />
                ) : (
                  <Text style={styles.predictBtnText}>Calculate Target Shot Output</Text>
                )}
              </TouchableOpacity>

              {aiResult && (
                <View style={[styles.aiResultCard, { borderColor: colors.primary, backgroundColor: colors.primaryGlow }]}>
                  <Text style={[styles.aiResultTitle, { color: colors.primary }]}>AI Output Prediction</Text>
                  <Text style={[styles.resultText, { color: colors.text }]}>
                    Predicted Shot Weight: <Text style={{ fontWeight: '700' }}>{aiResult.predictedShotWeight || 'N/A'}</Text>
                  </Text>
                  <Text style={[styles.resultText, { color: colors.text }]}>
                    Estimated Speed Factor: <Text style={{ fontWeight: '700' }}>{aiResult.speedFactor || 'N/A'}</Text>
                  </Text>
                  <Text style={[styles.resultText, { color: colors.text }]}>
                    Optimal Vulcanization Time: <Text style={{ fontWeight: '700' }}>{aiResult.optimalVulcanizationTime || 'N/A'}</Text>
                  </Text>
                </View>
              )}
            </ScrollView>
          )}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  tabScroll: {
    maxHeight: 50,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  tabContent: {
    paddingHorizontal: 8,
  },
  tab: {
    paddingHorizontal: 16,
    paddingVertical: 14,
    alignItems: 'center',
  },
  tabText: {
    fontSize: 14,
    fontWeight: '700',
  },
  listPadding: {
    padding: 16,
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    borderWidth: 1,
    padding: 16,
    marginBottom: 12,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: '700',
  },
  qtyText: {
    fontSize: 15,
    fontWeight: '700',
  },
  statusText: {
    fontSize: 13,
    fontWeight: '700',
  },
  statusBadge: {
    fontSize: 11,
    fontWeight: '700',
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 8,
  },
  actionBtn: {
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 12,
  },
  actionBtnText: {
    color: '#ffffff',
    fontWeight: '700',
    fontSize: 13,
  },
  emptyText: {
    textAlign: 'center',
    marginTop: 40,
    fontSize: 14,
    color: '#64748b',
  },
  formPadding: {
    padding: 20,
  },
  formTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 16,
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 12,
    fontSize: 15,
    backgroundColor: '#ffffff',
  },
  predictBtn: {
    borderRadius: 8,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 12,
  },
  predictBtnText: {
    color: '#ffffff',
    fontWeight: '700',
    fontSize: 15,
  },
  aiResultCard: {
    marginTop: 20,
    borderRadius: 12,
    borderWidth: 1,
    padding: 16,
    marginBottom: 24,
  },
  aiResultTitle: {
    fontSize: 15,
    fontWeight: '700',
    marginBottom: 8,
  },
  resultText: {
    fontSize: 14,
    marginBottom: 4,
  },
});
