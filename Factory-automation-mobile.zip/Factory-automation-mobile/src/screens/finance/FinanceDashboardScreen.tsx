import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
  Alert,
  FlatList,
  Modal,
  Linking,
} from 'react-native';
import { useOrg } from '../../context/OrgContext';
import { financeAPI } from '../../services/api';

export default function FinanceDashboardScreen() {
  const { colors } = useOrg();
  const [activeTab, setActiveTab] = useState<'invoices' | 'pos' | 'vendors'>('invoices');
  const [invoices, setInvoices] = useState<any[]>([]);
  const [pos, setPos] = useState<any[]>([]);
  const [vendors, setVendors] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Modals
  const [showVendorModal, setShowVendorModal] = useState(false);
  const [showPOModal, setShowPOModal] = useState(false);

  // Form states
  const [vendorName, setVendorName] = useState('');
  const [gstNumber, setGstNumber] = useState('');
  const [materialSupplied, setMaterialSupplied] = useState('Nylon');

  const [selectedVendorId, setSelectedVendorId] = useState('');
  const [poMaterialType, setPoMaterialType] = useState('Nylon');
  const [poQuantity, setPoQuantity] = useState('');
  const [poRate, setPoRate] = useState('');

  const fetchData = async () => {
    setLoading(true);
    try {
      const [invRes, vendRes, poRes] = await Promise.all([
        financeAPI.getInvoices().catch(() => ({ data: { data: [] } })),
        financeAPI.getVendors().catch(() => ({ data: { data: [] } })),
        financeAPI.getPOs().catch(() => ({ data: { data: [] } })),
      ]);
      setInvoices(invRes.data.data);
      setVendors(vendRes.data.data);
      setPos(poRes.data.data);
    } catch (err) {
      console.warn(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [activeTab]);

  const handleAddVendor = async () => {
    if (!vendorName) {
      Alert.alert('Error', 'Please enter a vendor name');
      return;
    }
    setSubmitting(true);
    try {
      await financeAPI.addVendor({ vendorName, gstNumber, materialSupplied });
      Alert.alert('Success', 'Vendor added successfully');
      setShowVendorModal(false);
      setVendorName('');
      setGstNumber('');
      fetchData();
    } catch (err) {
      console.warn(err);
      Alert.alert('Error', 'Failed to add vendor');
    } finally {
      setSubmitting(false);
    }
  };

  const handleCreatePO = async () => {
    if (!selectedVendorId || !poQuantity || !poRate) {
      Alert.alert('Error', 'Please fill in all PO fields');
      return;
    }
    setSubmitting(true);
    try {
      await financeAPI.createPO({
        vendorId: selectedVendorId,
        materialType: poMaterialType,
        quantityKg: parseFloat(poQuantity),
        ratePerKg: parseFloat(poRate),
      });
      Alert.alert('Success', 'Purchase Order Created');
      setShowPOModal(false);
      setPoQuantity('');
      setPoRate('');
      fetchData();
    } catch (err) {
      console.warn(err);
      Alert.alert('Error', 'Failed to create PO');
    } finally {
      setSubmitting(false);
    }
  };

  const handleScanInvoiceSimulate = async () => {
    setSubmitting(true);
    // Simulate uploading a file to OCR scanner
    try {
      const mockInvoiceData = {
        invoiceNumber: `OCR-INV-${Math.floor(100000 + Math.random() * 900000)}`,
        vendorName: vendors.length > 0 ? vendors[0].vendorName : 'Acme Raw Materials',
        totalAmount: 18450,
        taxAmount: 3321,
        rawOcrText: 'INWARD TAX BILL MOCK OCR RESULT NYLON SUPPLY QUANTITY 500KG',
        status: 'verified',
      };

      // Create simulated OCR record on the server (by calling normal add invoice or simulated OCR endpoint)
      // Since normal OCR scanner endpoint takes FormData, we can mock call
      Alert.alert('OCR Scanning (Simulated)', `Extracted invoice: ${mockInvoiceData.invoiceNumber} from ${mockInvoiceData.vendorName} for ₹${mockInvoiceData.totalAmount}`);
      fetchData();
    } catch (err) {
      console.warn(err);
      Alert.alert('Error', 'OCR scan failed');
    } finally {
      setSubmitting(false);
    }
  };

  const handleOpenPOPDF = (po: any) => {
    const url = `https://trackbells.com/api/finance/pos/${po._id}/pdf`;
    Alert.alert('PO PDF', `Opening Purchase Order #${po.poNumber || 'PO'}`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Open in Browser', onPress: () => Linking.openURL(url) },
    ]);
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Tab Header */}
      <View style={[styles.tabContainer, { borderBottomColor: colors.border }]}>
        {(['invoices', 'pos', 'vendors'] as const).map((tab) => (
          <TouchableOpacity
            key={tab}
            style={[
              styles.tab,
              activeTab === tab && { borderBottomColor: colors.primary, borderBottomWidth: 3 },
            ]}
            onPress={() => setActiveTab(tab)}
          >
            <Text
              style={[
                styles.tabText,
                { color: activeTab === tab ? colors.primary : colors.textSecondary },
              ]}
            >
              {tab === 'invoices' ? 'AI Invoices' : tab === 'pos' ? 'Purchase Orders' : 'Vendors'}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Main content */}
      <View style={styles.content}>
        {activeTab === 'invoices' && (
          <View style={[styles.ocrBanner, { borderColor: colors.primary, backgroundColor: colors.primaryGlow }]}>
            <Text style={[styles.ocrTitle, { color: colors.primary }]}>📸 AI Invoice Scanner (OCR)</Text>
            <Text style={[styles.ocrDesc, { color: colors.textSecondary }]}>
              Simulate uploading a scanned bill to automatically extract invoice number, vendor, and amounts.
            </Text>
            <TouchableOpacity
              style={[styles.ocrBtn, { backgroundColor: colors.primary }]}
              onPress={handleScanInvoiceSimulate}
              disabled={submitting}
            >
              <Text style={styles.ocrBtnText}>Simulate Invoice scan</Text>
            </TouchableOpacity>
          </View>
        )}

        {loading ? (
          <ActivityIndicator color={colors.primary} style={{ marginTop: 40 }} />
        ) : (
          <View style={{ flex: 1 }}>
            {activeTab === 'invoices' && (
              <FlatList
                data={invoices}
                keyExtractor={(item) => item._id}
                renderItem={({ item }) => (
                  <View style={[styles.card, { borderColor: colors.border }]}>
                    <View style={styles.cardHeader}>
                      <Text style={[styles.cardTitle, { color: colors.text }]}>Inv #{item.invoiceNumber}</Text>
                      <Text style={{ color: colors.primary, fontWeight: '700' }}>₹{item.totalAmount}</Text>
                    </View>
                    <Text style={{ color: colors.textSecondary }}>Vendor: {item.vendorName}</Text>
                    <Text style={{ color: colors.textMuted, fontSize: 12 }}>Tax amount: ₹{item.taxAmount}</Text>
                  </View>
                )}
                ListEmptyComponent={<Text style={styles.emptyText}>No invoices scanned yet</Text>}
              />
            )}

            {activeTab === 'pos' && (
              <View style={{ flex: 1 }}>
                <TouchableOpacity
                  style={[styles.createBtn, { backgroundColor: colors.primary }]}
                  onPress={() => setShowPOModal(true)}
                >
                  <Text style={styles.createBtnText}>+ Create Purchase Order</Text>
                </TouchableOpacity>

                <FlatList
                  data={pos}
                  keyExtractor={(item) => item._id}
                  renderItem={({ item }) => (
                    <View style={[styles.card, { borderColor: colors.border }]}>
                      <View style={styles.cardHeader}>
                        <Text style={[styles.cardTitle, { color: colors.text }]}>PO: {item.poNumber || 'PO'}</Text>
                        <Text style={{ color: colors.success, fontWeight: '700' }}>
                          ₹{item.totalAmount}
                        </Text>
                      </View>
                      <Text style={{ color: colors.textSecondary }}>Vendor: {item.vendorId?.vendorName || 'N/A'}</Text>
                      <Text style={{ color: colors.textMuted, fontSize: 13 }}>
                        Material: {item.materialType} | Qty: {item.quantityKg} kg
                      </Text>
                      <TouchableOpacity style={styles.pdfBtn} onPress={() => handleOpenPOPDF(item)}>
                        <Text style={{ color: colors.info, fontWeight: '700', fontSize: 13 }}>
                          📄 Download PO PDF
                        </Text>
                      </TouchableOpacity>
                    </View>
                  )}
                  ListEmptyComponent={<Text style={styles.emptyText}>No purchase orders found</Text>}
                />
              </View>
            )}

            {activeTab === 'vendors' && (
              <View style={{ flex: 1 }}>
                <TouchableOpacity
                  style={[styles.createBtn, { backgroundColor: colors.primary }]}
                  onPress={() => setShowVendorModal(true)}
                >
                  <Text style={styles.createBtnText}>+ Add New Vendor</Text>
                </TouchableOpacity>

                <FlatList
                  data={vendors}
                  keyExtractor={(item) => item._id}
                  renderItem={({ item }) => (
                    <View style={[styles.card, { borderColor: colors.border }]}>
                      <Text style={[styles.cardTitle, { color: colors.text, marginBottom: 4 }]}>
                        {item.vendorName}
                      </Text>
                      <Text style={{ color: colors.textSecondary, fontSize: 13 }}>GST: {item.gstNumber || 'N/A'}</Text>
                      <Text style={{ color: colors.textMuted, fontSize: 12 }}>Supplies: {item.materialSupplied}</Text>
                    </View>
                  )}
                  ListEmptyComponent={<Text style={styles.emptyText}>No vendors registered</Text>}
                />
              </View>
            )}
          </View>
        )}
      </View>

      {/* Vendor Modal */}
      <Modal visible={showVendorModal} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Add Vendor</Text>
            <ScrollView keyboardShouldPersistTaps="handled">
              <View style={styles.inputGroup}>
                <Text style={styles.label}>Vendor Name *</Text>
                <TextInput
                  style={[styles.input, { borderColor: colors.border }]}
                  placeholder="e.g. Nylon Corp Ltd"
                  value={vendorName}
                  onChangeText={setVendorName}
                />
              </View>
              <View style={styles.inputGroup}>
                <Text style={styles.label}>GST Number</Text>
                <TextInput
                  style={[styles.input, { borderColor: colors.border }]}
                  placeholder="e.g. 07AAAAA1111A1Z1"
                  value={gstNumber}
                  onChangeText={setGstNumber}
                  autoCapitalize="characters"
                />
              </View>
              <View style={styles.inputGroup}>
                <Text style={styles.label}>Material Supplied</Text>
                <TextInput
                  style={[styles.input, { borderColor: colors.border }]}
                  placeholder="e.g. Nylon 6, Pigments"
                  value={materialSupplied}
                  onChangeText={setMaterialSupplied}
                />
              </View>
              <View style={styles.modalButtons}>
                <TouchableOpacity style={styles.cancelBtn} onPress={() => setShowVendorModal(false)}>
                  <Text>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.submitBtn, { backgroundColor: colors.primary }]} onPress={handleAddVendor}>
                  <Text style={{ color: '#ffffff', fontWeight: '700' }}>Save Vendor</Text>
                </TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Purchase Order Modal */}
      <Modal visible={showPOModal} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Create Purchase Order</Text>
            <ScrollView keyboardShouldPersistTaps="handled">
              <View style={styles.inputGroup}>
                <Text style={styles.label}>Select Vendor *</Text>
                {/* Simplified simulated picker list */}
                <ScrollView style={{ maxHeight: 100, borderWidth: 1, borderColor: colors.border, borderRadius: 8, padding: 8 }}>
                  {vendors.map((v) => (
                    <TouchableOpacity
                      key={v._id}
                      style={{ paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: '#f1f5f9' }}
                      onPress={() => setSelectedVendorId(v._id)}
                    >
                      <Text style={{ color: selectedVendorId === v._id ? colors.primary : colors.text, fontWeight: selectedVendorId === v._id ? '700' : '400' }}>
                        {v.vendorName}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>Material Type</Text>
                <TextInput
                  style={[styles.input, { borderColor: colors.border }]}
                  placeholder="e.g. Nylon Raw"
                  value={poMaterialType}
                  onChangeText={setPoMaterialType}
                />
              </View>

              <View style={styles.row}>
                <View style={[styles.inputGroup, { flex: 1, marginRight: 8 }]}>
                  <Text style={styles.label}>Quantity (kg) *</Text>
                  <TextInput
                    style={[styles.input, { borderColor: colors.border }]}
                    placeholder="0"
                    keyboardType="numeric"
                    value={poQuantity}
                    onChangeText={poQuantity => setPoQuantity(poQuantity)}
                  />
                </View>
                <View style={[styles.inputGroup, { flex: 1 }]}>
                  <Text style={styles.label}>Rate per kg (₹) *</Text>
                  <TextInput
                    style={[styles.input, { borderColor: colors.border }]}
                    placeholder="0"
                    keyboardType="numeric"
                    value={poRate}
                    onChangeText={poRate => setPoRate(poRate)}
                  />
                </View>
              </View>

              <View style={styles.modalButtons}>
                <TouchableOpacity style={styles.cancelBtn} onPress={() => setShowPOModal(false)}>
                  <Text>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.submitBtn, { backgroundColor: colors.primary }]} onPress={handleCreatePO}>
                  <Text style={{ color: '#ffffff', fontWeight: '700' }}>Create PO</Text>
                </TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  tabContainer: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    backgroundColor: '#ffffff',
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 14,
  },
  tabText: {
    fontSize: 14,
    fontWeight: '700',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  ocrBanner: {
    borderWidth: 1,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  ocrTitle: {
    fontSize: 15,
    fontWeight: '700',
    marginBottom: 4,
  },
  ocrDesc: {
    fontSize: 12,
    lineHeight: 18,
    marginBottom: 12,
  },
  ocrBtn: {
    alignSelf: 'flex-start',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  ocrBtnText: {
    color: '#ffffff',
    fontWeight: '700',
    fontSize: 12,
  },
  createBtn: {
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 16,
  },
  createBtnText: {
    color: '#ffffff',
    fontWeight: '700',
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    borderWidth: 1,
    padding: 16,
    marginBottom: 12,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  cardTitle: {
    fontSize: 15,
    fontWeight: '700',
  },
  pdfBtn: {
    marginTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
    paddingTop: 8,
  },
  emptyText: {
    textAlign: 'center',
    marginTop: 40,
    color: '#64748b',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 24,
    maxHeight: '80%',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 16,
    textAlign: 'center',
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 12,
    fontSize: 15,
  },
  row: {
    flexDirection: 'row',
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 16,
  },
  cancelBtn: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  submitBtn: {
    flex: 2,
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
