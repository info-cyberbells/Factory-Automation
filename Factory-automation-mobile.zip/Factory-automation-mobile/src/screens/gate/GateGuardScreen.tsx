import React, { useState, useEffect, useCallback } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Alert,
  FlatList,
} from 'react-native';
import { useOrg } from '../../context/OrgContext';
import { gateEntryAPI } from '../../services/api';

export default function GateGuardScreen() {
  const { colors } = useOrg();
  const [activeTab, setActiveTab] = useState<'new' | 'history'>('new');
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [search, setSearch] = useState('');
  const [entries, setEntries] = useState<any[]>([]);

  // Form State
  const [billNumber, setBillNumber] = useState('');
  const [vendorName, setVendorName] = useState('');
  const [vendorContact, setVendorContact] = useState('');
  const [materialType, setMaterialType] = useState('nylon');
  const [materialDescription, setMaterialDescription] = useState('');
  const [quantity, setQuantity] = useState('');
  const [unit, setUnit] = useState('kg');
  const [vehicleNumber, setVehicleNumber] = useState('');
  const [driverName, setDriverName] = useState('');

  const fetchLogs = useCallback(async () => {
    setLoading(true);
    try {
      const res = await gateEntryAPI.getAll({ search });
      setEntries(res.data.data);
    } catch (err) {
      console.warn(err);
    } finally {
      setLoading(false);
    }
  }, [search]);

  useEffect(() => {
    if (activeTab === 'history') {
      fetchLogs();
    }
  }, [activeTab, fetchLogs]);

  const handleSubmit = async () => {
    if (!billNumber || !vendorName || !quantity) {
      Alert.alert('Error', 'Please fill in all required fields (*)');
      return;
    }
    setSubmitting(true);
    try {
      const data = {
        billNumber,
        vendorName,
        vendorContact,
        materialType,
        materialDescription,
        quantity: parseFloat(quantity),
        unit,
        vehicleNumber,
        driverName,
      };

      await gateEntryAPI.create(data);
      Alert.alert('Success', 'Gate entry saved successfully!');
      
      // Reset form
      setBillNumber('');
      setVendorName('');
      setVendorContact('');
      setMaterialType('nylon');
      setMaterialDescription('');
      setQuantity('');
      setUnit('kg');
      setVehicleNumber('');
      setDriverName('');
      
      setActiveTab('history');
    } catch (err: any) {
      const msg = err.response?.data?.message || 'Failed to save gate entry';
      Alert.alert('Error', msg);
    } finally {
      setSubmitting(false);
    }
  };

  const renderLogItem = ({ item }: { item: any }) => (
    <View style={[styles.logCard, { borderColor: colors.border }]}>
      <View style={styles.logHeader}>
        <Text style={[styles.billText, { color: colors.text }]}>Bill: {item.billNumber}</Text>
        <Text
          style={[
            styles.typeBadge,
            {
              backgroundColor: colors.primaryGlow,
              color: colors.primary,
            },
          ]}
        >
          {item.materialType.toUpperCase()}
        </Text>
      </View>
      <Text style={[styles.vendorText, { color: colors.textSecondary }]}>
        Vendor: {item.vendorName}
      </Text>
      <Text style={[styles.vehicleText, { color: colors.textMuted }]}>
        Vehicle: {item.vehicleNumber || 'N/A'} | Driver: {item.driverName || 'N/A'}
      </Text>
      <Text style={[styles.qtyText, { color: colors.primary }]}>
        Qty: {item.quantity} {item.unit}
      </Text>
      {item.status && (
        <Text style={[styles.statusText, { color: item.status === 'verified' ? colors.success : colors.warning }]}>
          Status: {item.status.toUpperCase()}
        </Text>
      )}
    </View>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Switcher Tab Header */}
      <View style={[styles.tabContainer, { borderBottomColor: colors.border }]}>
        <TouchableOpacity
          style={[
            styles.tab,
            activeTab === 'new' && { borderBottomColor: colors.primary, borderBottomWidth: 3 },
          ]}
          onPress={() => setActiveTab('new')}
        >
          <Text
            style={[
              styles.tabText,
              { color: activeTab === 'new' ? colors.primary : colors.textSecondary },
            ]}
          >
            Log Inward
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.tab,
            activeTab === 'history' && { borderBottomColor: colors.primary, borderBottomWidth: 3 },
          ]}
          onPress={() => setActiveTab('history')}
        >
          <Text
            style={[
              styles.tabText,
              { color: activeTab === 'history' ? colors.primary : colors.textSecondary },
            ]}
          >
            Gate Logs
          </Text>
        </TouchableOpacity>
      </View>

      {activeTab === 'new' ? (
        <ScrollView contentContainerStyle={styles.formContainer} keyboardShouldPersistTaps="handled">
          <View style={styles.inputGroup}>
            <Text style={[styles.label, { color: colors.textSecondary }]}>Bill / Invoice Number *</Text>
            <TextInput
              style={[styles.input, { borderColor: colors.border, color: colors.text }]}
              placeholder="e.g. BILL-99231"
              placeholderTextColor={colors.textGhost}
              value={billNumber}
              onChangeText={setBillNumber}
            />
          </View>

          <View style={styles.row}>
            <View style={[styles.inputGroup, { flex: 1, marginRight: 8 }]}>
              <Text style={[styles.label, { color: colors.textSecondary }]}>Vendor Name *</Text>
              <TextInput
                style={[styles.input, { borderColor: colors.border, color: colors.text }]}
                placeholder="Nylon Corp"
                placeholderTextColor={colors.textGhost}
                value={vendorName}
                onChangeText={setVendorName}
              />
            </View>
            <View style={[styles.inputGroup, { flex: 1 }]}>
              <Text style={[styles.label, { color: colors.textSecondary }]}>Vendor Contact</Text>
              <TextInput
                style={[styles.input, { borderColor: colors.border, color: colors.text }]}
                placeholder="+91 9999..."
                placeholderTextColor={colors.textGhost}
                value={vendorContact}
                onChangeText={setVendorContact}
                keyboardType="phone-pad"
              />
            </View>
          </View>

          <View style={styles.row}>
            <View style={[styles.inputGroup, { flex: 1, marginRight: 8 }]}>
              <Text style={[styles.label, { color: colors.textSecondary }]}>Material Type *</Text>
              {/* Simplified Selector buttons */}
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginVertical: 4 }}>
                {['nylon', 'pigment', 'packaging', 'hardware', 'other'].map((type) => (
                  <TouchableOpacity
                    key={type}
                    style={[
                      styles.smallBadge,
                      {
                        backgroundColor: materialType === type ? colors.primary : '#ffffff',
                        borderColor: colors.border,
                        borderWidth: 1,
                      },
                    ]}
                    onPress={() => setMaterialType(type)}
                  >
                    <Text
                      style={{
                        color: materialType === type ? '#ffffff' : colors.textSecondary,
                        fontSize: 12,
                        fontWeight: '600',
                      }}
                    >
                      {type}
                    </Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>
            </View>
          </View>

          <View style={styles.row}>
            <View style={[styles.inputGroup, { flex: 2, marginRight: 8 }]}>
              <Text style={[styles.label, { color: colors.textSecondary }]}>Quantity *</Text>
              <TextInput
                style={[styles.input, { borderColor: colors.border, color: colors.text }]}
                placeholder="0.00"
                placeholderTextColor={colors.textGhost}
                value={quantity}
                onChangeText={setQuantity}
                keyboardType="numeric"
              />
            </View>
            <View style={[styles.inputGroup, { flex: 1 }]}>
              <Text style={[styles.label, { color: colors.textSecondary }]}>Unit</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginVertical: 4 }}>
                {['kg', 'pcs', 'meters', 'liters', 'bags'].map((u) => (
                  <TouchableOpacity
                    key={u}
                    style={[
                      styles.smallBadge,
                      {
                        backgroundColor: unit === u ? colors.primary : '#ffffff',
                        borderColor: colors.border,
                        borderWidth: 1,
                      },
                    ]}
                    onPress={() => setUnit(u)}
                  >
                    <Text
                      style={{
                        color: unit === u ? '#ffffff' : colors.textSecondary,
                        fontSize: 12,
                        fontWeight: '600',
                      }}
                    >
                      {u}
                    </Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>
            </View>
          </View>

          <View style={styles.row}>
            <View style={[styles.inputGroup, { flex: 1, marginRight: 8 }]}>
              <Text style={[styles.label, { color: colors.textSecondary }]}>Vehicle Number</Text>
              <TextInput
                style={[styles.input, { borderColor: colors.border, color: colors.text }]}
                placeholder="e.g. DL-01-AB-1234"
                placeholderTextColor={colors.textGhost}
                value={vehicleNumber}
                onChangeText={setVehicleNumber}
                autoCapitalize="characters"
              />
            </View>
            <View style={[styles.inputGroup, { flex: 1 }]}>
              <Text style={[styles.label, { color: colors.textSecondary }]}>Driver Name</Text>
              <TextInput
                style={[styles.input, { borderColor: colors.border, color: colors.text }]}
                placeholder="Driver Name"
                placeholderTextColor={colors.textGhost}
                value={driverName}
                onChangeText={setDriverName}
              />
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={[styles.label, { color: colors.textSecondary }]}>Description / Remarks</Text>
            <TextInput
              style={[styles.input, styles.textArea, { borderColor: colors.border, color: colors.text }]}
              placeholder="Item details, packaging condition..."
              placeholderTextColor={colors.textGhost}
              value={materialDescription}
              onChangeText={setMaterialDescription}
              multiline
              numberOfLines={3}
            />
          </View>

          <TouchableOpacity
            style={[styles.submitButton, { backgroundColor: colors.primary }]}
            onPress={handleSubmit}
            disabled={submitting}
          >
            {submitting ? (
              <ActivityIndicator color="#ffffff" />
            ) : (
              <Text style={styles.submitButtonText}>Save & Dispatch Inward</Text>
            )}
          </TouchableOpacity>
        </ScrollView>
      ) : (
        <View style={styles.listContainer}>
          {/* Search Box */}
          <View style={styles.searchWrapper}>
            <TextInput
              style={[styles.searchInput, { borderColor: colors.border, color: colors.text }]}
              placeholder="Search by Bill/Vendor..."
              placeholderTextColor={colors.textGhost}
              value={search}
              onChangeText={setSearch}
            />
          </View>

          {loading ? (
            <ActivityIndicator color={colors.primary} style={{ marginTop: 40 }} />
          ) : (
            <FlatList
              data={entries}
              keyExtractor={(item) => item._id}
              renderItem={renderLogItem}
              contentContainerStyle={styles.listContent}
              ListEmptyComponent={
                <Text style={[styles.emptyText, { color: colors.textMuted }]}>
                  No gate entries found.
                </Text>
              }
            />
          )}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  tabContainer: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    backgroundColor: '#ffffff',
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 14,
  },
  tabText: {
    fontSize: 15,
    fontWeight: '700',
  },
  formContainer: {
    padding: 20,
  },
  inputGroup: {
    marginBottom: 16,
  },
  row: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 12,
    fontSize: 15,
    backgroundColor: '#ffffff',
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top',
  },
  smallBadge: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 16,
    marginRight: 8,
  },
  submitButton: {
    borderRadius: 8,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 12,
    marginBottom: 24,
  },
  submitButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '700',
  },
  listContainer: {
    flex: 1,
    padding: 16,
  },
  searchWrapper: {
    marginBottom: 16,
  },
  searchInput: {
    borderWidth: 1,
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 16,
    fontSize: 15,
    backgroundColor: '#ffffff',
  },
  listContent: {
    paddingBottom: 24,
  },
  logCard: {
    backgroundColor: '#ffffff',
    borderRadius: 10,
    borderWidth: 1,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#0f172a',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.02,
    shadowRadius: 2,
    elevation: 1,
  },
  logHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  billText: {
    fontSize: 15,
    fontWeight: '700',
  },
  typeBadge: {
    fontSize: 10,
    fontWeight: '700',
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 12,
  },
  vendorText: {
    fontSize: 14,
    marginBottom: 4,
  },
  vehicleText: {
    fontSize: 12,
    marginBottom: 6,
  },
  qtyText: {
    fontSize: 14,
    fontWeight: '700',
  },
  statusText: {
    fontSize: 12,
    fontWeight: '700',
    marginTop: 6,
  },
  emptyText: {
    textAlign: 'center',
    marginTop: 40,
    fontSize: 14,
  },
});
