import React, { useState } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Alert,
} from 'react-native';
import { useOrg } from '../../context/OrgContext';
import { authAPI } from '../../services/api';

export default function SignupScreen({ navigation }: any) {
  const { colors } = useOrg();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);

  // Form Fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [orgName, setOrgName] = useState('');
  const [industry, setIndustry] = useState('Manufacturing');
  const [orgAddress, setOrgAddress] = useState('');

  const [otpCode, setOtpCode] = useState('');

  // Password visibility
  const [secureText, setSecureText] = useState(true);
  const [secureConfirmText, setSecureConfirmText] = useState(true);

  const handleNextStep1 = () => {
    if (!name || !email || !password || !confirmPassword) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }
    if (password.length < 6) {
      Alert.alert('Error', 'Password must be at least 6 characters');
      return;
    }
    if (password !== confirmPassword) {
      Alert.alert('Error', 'Passwords do not match');
      return;
    }
    setStep(2);
  };

  const handleNextStep2 = async () => {
    if (!orgName) {
      Alert.alert('Error', 'Please enter an Organization Name');
      return;
    }
    setLoading(true);
    try {
      await authAPI.onboardSendOTP({ email: email.trim().toLowerCase() });
      Alert.alert('Success', 'Verification code sent to your email!');
      setStep(3);
    } catch (error: any) {
      Alert.alert(
        'Verification Failed',
        error.response?.data?.message || 'Failed to send OTP. Email may already exist.'
      );
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitFinal = async () => {
    if (!otpCode || otpCode.length !== 6) {
      Alert.alert('Error', 'Please enter a valid 6-digit OTP');
      return;
    }
    setLoading(true);
    try {
      const res = await authAPI.onboardVerifyOrg({
        personalDetails: {
          name,
          email: email.trim().toLowerCase(),
          phone,
          password,
        },
        orgDetails: {
          name: orgName,
          industry,
          address: orgAddress,
        },
        otpCode,
      });

      Alert.alert('Success', res.data.message || 'Application submitted successfully!', [
        { text: 'OK', onPress: () => navigation.navigate('Login') },
      ]);
    } catch (error: any) {
      Alert.alert('Error', error.response?.data?.message || 'Invalid or expired OTP');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={[styles.container, { backgroundColor: colors.background }]}
    >
      <ScrollView contentContainerStyle={styles.scrollContainer} keyboardShouldPersistTaps="handled">
        {/* Step Indicator Header */}
        <View style={styles.stepHeader}>
          <Text style={[styles.stepTitle, { color: colors.text }]}>Create Admin Account</Text>
          <View style={styles.stepBarWrapper}>
            <View
              style={[
                styles.stepBar,
                { backgroundColor: step >= 1 ? colors.primary : colors.border },
              ]}
            />
            <View
              style={[
                styles.stepBar,
                { backgroundColor: step >= 2 ? colors.primary : colors.border },
              ]}
            />
            <View
              style={[
                styles.stepBar,
                { backgroundColor: step >= 3 ? colors.primary : colors.border },
              ]}
            />
          </View>
          <Text style={[styles.stepText, { color: colors.textMuted }]}>
            Step {step} of 3:{' '}
            {step === 1
              ? 'Admin Profile'
              : step === 2
              ? 'Organization Details'
              : 'Verify Email'}
          </Text>
        </View>

        {step === 1 && (
          <View style={styles.form}>
            <View style={styles.inputContainer}>
              <Text style={[styles.label, { color: colors.textSecondary }]}>Full Name *</Text>
              <TextInput
                style={[styles.input, { borderColor: colors.border, color: colors.text }]}
                placeholder="Enter your full name"
                placeholderTextColor={colors.textGhost}
                value={name}
                onChangeText={setName}
                autoCorrect={false}
              />
            </View>

            <View style={styles.inputContainer}>
              <Text style={[styles.label, { color: colors.textSecondary }]}>Email Address *</Text>
              <TextInput
                style={[styles.input, { borderColor: colors.border, color: colors.text }]}
                placeholder="Enter your email"
                placeholderTextColor={colors.textGhost}
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                autoCorrect={false}
              />
            </View>

            <View style={styles.inputContainer}>
              <Text style={[styles.label, { color: colors.textSecondary }]}>Phone Number</Text>
              <TextInput
                style={[styles.input, { borderColor: colors.border, color: colors.text }]}
                placeholder="Enter your phone number"
                placeholderTextColor={colors.textGhost}
                value={phone}
                onChangeText={setPhone}
                keyboardType="phone-pad"
              />
            </View>

            <View style={styles.inputContainer}>
              <Text style={[styles.label, { color: colors.textSecondary }]}>Password *</Text>
              <View style={styles.passwordWrapper}>
                <TextInput
                  style={[
                    styles.input,
                    styles.passwordInput,
                    { borderColor: colors.border, color: colors.text },
                  ]}
                  placeholder="Min 6 characters"
                  placeholderTextColor={colors.textGhost}
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry={secureText}
                  autoCapitalize="none"
                  autoCorrect={false}
                />
                <TouchableOpacity
                  style={styles.eyeButton}
                  onPress={() => setSecureText(!secureText)}
                >
                  <Text style={{ color: colors.primary, fontWeight: '600' }}>
                    {secureText ? 'Show' : 'Hide'}
                  </Text>
                </TouchableOpacity>
              </View>
            </View>

            <View style={styles.inputContainer}>
              <Text style={[styles.label, { color: colors.textSecondary }]}>Confirm Password *</Text>
              <View style={styles.passwordWrapper}>
                <TextInput
                  style={[
                    styles.input,
                    styles.passwordInput,
                    { borderColor: colors.border, color: colors.text },
                  ]}
                  placeholder="Confirm your password"
                  placeholderTextColor={colors.textGhost}
                  value={confirmPassword}
                  onChangeText={setConfirmPassword}
                  secureTextEntry={secureConfirmText}
                  autoCapitalize="none"
                  autoCorrect={false}
                />
                <TouchableOpacity
                  style={styles.eyeButton}
                  onPress={() => setSecureConfirmText(!secureConfirmText)}
                >
                  <Text style={{ color: colors.primary, fontWeight: '600' }}>
                    {secureConfirmText ? 'Show' : 'Hide'}
                  </Text>
                </TouchableOpacity>
              </View>
            </View>

            <TouchableOpacity
              style={[styles.button, { backgroundColor: colors.primary }]}
              onPress={handleNextStep1}
            >
              <Text style={styles.buttonText}>Continue to Organization</Text>
            </TouchableOpacity>
          </View>
        )}

        {step === 2 && (
          <View style={styles.form}>
            <View style={styles.inputContainer}>
              <Text style={[styles.label, { color: colors.textSecondary }]}>
                Organization Name *
              </Text>
              <TextInput
                style={[styles.input, { borderColor: colors.border, color: colors.text }]}
                placeholder="e.g. Acme Manufacturing"
                placeholderTextColor={colors.textGhost}
                value={orgName}
                onChangeText={setOrgName}
                autoCorrect={false}
              />
            </View>

            <View style={styles.inputContainer}>
              <Text style={[styles.label, { color: colors.textSecondary }]}>Industry</Text>
              {/* Dynamic simulated Picker / options */}
              <View style={styles.rowPicker}>
                {['Manufacturing', 'Logistics', 'Retail', 'Other'].map((ind) => (
                  <TouchableOpacity
                    key={ind}
                    style={[
                      styles.pickerOption,
                      {
                        borderColor: industry === ind ? colors.primary : colors.border,
                        backgroundColor: industry === ind ? colors.primaryGlow : '#ffffff',
                      },
                    ]}
                    onPress={() => setIndustry(ind)}
                  >
                    <Text
                      style={[
                        styles.pickerOptionText,
                        { color: industry === ind ? colors.primary : colors.textSecondary },
                      ]}
                    >
                      {ind}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            <View style={styles.inputContainer}>
              <Text style={[styles.label, { color: colors.textSecondary }]}>
                Address / Location
              </Text>
              <TextInput
                style={[styles.input, { borderColor: colors.border, color: colors.text }]}
                placeholder="City, Country"
                placeholderTextColor={colors.textGhost}
                value={orgAddress}
                onChangeText={setOrgAddress}
              />
            </View>

            <View style={styles.rowButtons}>
              <TouchableOpacity
                style={[styles.backButton, { borderColor: colors.border }]}
                onPress={() => setStep(1)}
              >
                <Text style={[styles.backButtonText, { color: colors.textSecondary }]}>Back</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.button, { backgroundColor: colors.primary, flex: 1 }]}
                onPress={handleNextStep2}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator color="#ffffff" />
                ) : (
                  <Text style={styles.buttonText}>Send Code</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        )}

        {step === 3 && (
          <View style={styles.form}>
            <View style={styles.inputContainer}>
              <Text style={[styles.label, { color: colors.textSecondary }]}>Enter 6-Digit OTP *</Text>
              <TextInput
                style={[
                  styles.input,
                  styles.otpInput,
                  { borderColor: colors.border, color: colors.text },
                ]}
                placeholder="000000"
                placeholderTextColor={colors.textGhost}
                value={otpCode}
                onChangeText={setOtpCode}
                keyboardType="number-pad"
                maxLength={6}
                autoCorrect={false}
              />
            </View>

            <View style={styles.rowButtons}>
              <TouchableOpacity
                style={[styles.backButton, { borderColor: colors.border }]}
                onPress={() => setStep(2)}
              >
                <Text style={[styles.backButtonText, { color: colors.textSecondary }]}>Back</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.button, { backgroundColor: colors.primary, flex: 1 }]}
                onPress={handleSubmitFinal}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator color="#ffffff" />
                ) : (
                  <Text style={styles.buttonText}>Verify & Register</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        )}

        <TouchableOpacity style={styles.loginLink} onPress={() => navigation.navigate('Login')}>
          <Text style={[styles.loginLinkText, { color: colors.textMuted }]}>
            Already have an account? <Text style={{ color: colors.primary, fontWeight: '700' }}>Sign In</Text>
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContainer: {
    flexGrow: 1,
    padding: 24,
    justifyContent: 'center',
  },
  stepHeader: {
    alignItems: 'center',
    marginBottom: 28,
  },
  stepTitle: {
    fontSize: 22,
    fontWeight: '700',
    marginBottom: 16,
  },
  stepBarWrapper: {
    flexDirection: 'row',
    width: '100%',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  stepBar: {
    flex: 1,
    height: 4,
    marginHorizontal: 4,
    borderRadius: 2,
  },
  stepText: {
    fontSize: 13,
  },
  form: {
    marginBottom: 20,
  },
  inputContainer: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderRadius: 10,
    paddingVertical: 12,
    paddingHorizontal: 16,
    fontSize: 15,
    backgroundColor: '#ffffff',
  },
  passwordWrapper: {
    position: 'relative',
    justifyContent: 'center',
  },
  passwordInput: {
    paddingRight: 60,
  },
  eyeButton: {
    position: 'absolute',
    right: 16,
    padding: 4,
  },
  rowPicker: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  pickerOption: {
    width: '48%',
    borderWidth: 1,
    borderRadius: 8,
    paddingVertical: 10,
    alignItems: 'center',
    marginBottom: 10,
  },
  pickerOptionText: {
    fontSize: 13,
    fontWeight: '600',
  },
  rowButtons: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 16,
  },
  backButton: {
    borderWidth: 1,
    borderRadius: 10,
    paddingVertical: 14,
    paddingHorizontal: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  backButtonText: {
    fontSize: 15,
    fontWeight: '600',
  },
  button: {
    borderRadius: 10,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 15,
    fontWeight: '700',
  },
  otpInput: {
    fontSize: 24,
    letterSpacing: 8,
    textAlign: 'center',
  },
  loginLink: {
    alignItems: 'center',
    marginTop: 20,
  },
  loginLinkText: {
    fontSize: 14,
  },
});
