import React, { useState, useEffect, useCallback } from 'react';
import {
  StyleSheet,
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
  Alert,
  FlatList,
  Modal,
} from 'react-native';
import { useOrg } from '../../context/OrgContext';
import { operationsAPI } from '../../services/api';

export default function StoreGodownScreen() {
  const { colors } = useOrg();
  const [activeTab, setActiveTab] = useState<'inventory' | 'shortages' | 'qc'>('inventory');
  const [inventory, setInventory] = useState<any[]>([]);
  const [shortages, setShortages] = useState<any[]>([]);
  const [qcLogs, setQcLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [showItemModal, setShowItemModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Edit/Add Item Form State
  const [editingItemId, setEditingItemId] = useState<string | null>(null);
  const [itemName, setItemName] = useState('');
  const [itemType, setItemType] = useState('raw_material');
  const [quantity, setQuantity] = useState('');
  const [unit, setUnit] = useState('kg');
  const [location, setLocation] = useState('Unassigned');
  const [size, setSize] = useState('');
  const [description, setDescription] = useState('');

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      if (activeTab === 'inventory') {
        const res = await operationsAPI.getInventory();
        setInventory(res.data.data);
      } else if (activeTab === 'shortages') {
        const res = await operationsAPI.getShortageBuySales();
        setShortages(res.data.data.filter((item: any) => item.type === 'shortage'));
      } else if (activeTab === 'qc') {
        const res = await operationsAPI.getQualityLogs();
        setQcLogs(res.data.data);
      }
    } catch (err) {
      console.warn(err);
    } finally {
      setLoading(false);
    }
  }, [activeTab]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleSaveItem = async () => {
    if (!itemName || !quantity) {
      Alert.alert('Error', 'Please fill in name and quantity');
      return;
    }
    setSubmitting(true);
    try {
      const payload = {
        name: itemName,
        type: itemType,
        quantity: parseFloat(quantity),
        unit,
        location,
        size,
        description,
      };

      if (editingItemId) {
        await operationsAPI.updateInventoryItem(editingItemId, payload);
        Alert.alert('Success', 'Inventory item updated!');
      } else {
        await operationsAPI.createInventoryItem(payload);
        Alert.alert('Success', 'Inventory item created!');
      }

      setShowItemModal(false);
      setEditingItemId(null);
      setItemName('');
      setItemType('raw_material');
      setQuantity('');
      setUnit('kg');
      setLocation('Unassigned');
      setSize('');
      setDescription('');

      fetchData();
    } catch (err: any) {
      Alert.alert('Error', err.response?.data?.message || 'Failed to save item');
    } finally {
      setSubmitting(false);
    }
  };

  const handleEditItem = (item: any) => {
    setEditingItemId(item._id);
    setItemName(item.name);
    setItemType(item.type);
    setQuantity(item.quantity.toString());
    setUnit(item.unit);
    setLocation(item.location || 'Unassigned');
    setSize(item.size || '');
    setDescription(item.description || '');
    setShowItemModal(true);
  };

  const handleSendForQC = async (item: any) => {
    try {
      await operationsAPI.updateInventoryItem(item._id, {
        qualityStatus: 'sent_for_qc',
        qcRequestedAt: new Date(),
      });
      Alert.alert('QC Requested', `Sent "${item.name}" for Quality Control Check!`);
      fetchData();
    } catch (err) {
      console.warn(err);
      Alert.alert('Error', 'Failed to request quality check');
    }
  };

  const handleDeleteItem = (id: string) => {
    Alert.alert('Confirm Delete', 'Delete this inventory item?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            await operationsAPI.deleteInventoryItem(id);
            Alert.alert('Success', 'Item deleted');
            fetchData();
          } catch (err) {
            console.warn(err);
            Alert.alert('Error', 'Failed to delete item');
          }
        },
      },
    ]);
  };

  const getFilteredInventory = () => {
    return inventory.filter(
      (item) =>
        item.name.toLowerCase().includes(search.toLowerCase()) ||
        (item.location && item.location.toLowerCase().includes(search.toLowerCase()))
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Switcher Tab Header */}
      <View style={[styles.tabContainer, { borderBottomColor: colors.border }]}>
        {(['inventory', 'shortages', 'qc'] as const).map((tab) => (
          <TouchableOpacity
            key={tab}
            style={[
              styles.tab,
              activeTab === tab && { borderBottomColor: colors.primary, borderBottomWidth: 3 },
            ]}
            onPress={() => setActiveTab(tab)}
          >
            <Text
              style={[
                styles.tabText,
                { color: activeTab === tab ? colors.primary : colors.textSecondary },
              ]}
            >
              {tab === 'inventory' ? 'Inventory' : tab === 'shortages' ? 'Shortage logs' : 'QC Status'}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Main Content */}
      <View style={styles.content}>
        <View style={styles.headerActions}>
          <TextInput
            style={[styles.searchInput, { borderColor: colors.border, color: colors.text }]}
            placeholder="Search name, rack or bin..."
            placeholderTextColor={colors.textGhost}
            value={search}
            onChangeText={setSearch}
          />
          {activeTab === 'inventory' && (
            <TouchableOpacity
              style={[styles.addButton, { backgroundColor: colors.primary }]}
              onPress={() => {
                setEditingItemId(null);
                setShowItemModal(true);
              }}
            >
              <Text style={styles.addButtonText}>Add Stock</Text>
            </TouchableOpacity>
          )}
        </View>

        {loading ? (
          <ActivityIndicator color={colors.primary} style={{ marginTop: 40 }} />
        ) : (
          <View style={{ flex: 1 }}>
            {activeTab === 'inventory' && (
              <FlatList
                data={getFilteredInventory()}
                keyExtractor={(item) => item._id}
                renderItem={({ item }) => (
                  <View style={[styles.card, { borderColor: colors.border }]}>
                    <View style={styles.cardHeader}>
                      <Text style={[styles.cardTitle, { color: colors.text }]}>{item.name}</Text>
                      <Text style={[styles.qtyText, { color: colors.primary }]}>
                        {item.quantity} {item.unit}
                      </Text>
                    </View>
                    <Text style={{ color: colors.textSecondary, fontSize: 13 }}>
                      📍 Location: {item.location || 'Unassigned'}
                    </Text>
                    {item.size ? (
                      <Text style={{ color: colors.textSecondary, fontSize: 13 }}>📏 Size: {item.size}</Text>
                    ) : null}
                    {item.qualityStatus && (
                      <Text style={[styles.qcStatus, { color: colors.info }]}>
                        QC: {item.qualityStatus.toUpperCase().replace('_', ' ')}
                      </Text>
                    )}

                    <View style={styles.actionsRow}>
                      <TouchableOpacity style={styles.actionLink} onPress={() => handleEditItem(item)}>
                        <Text style={{ color: colors.primary, fontWeight: '700' }}>Edit</Text>
                      </TouchableOpacity>
                      {item.qualityStatus !== 'sent_for_qc' && (
                        <TouchableOpacity style={styles.actionLink} onPress={() => handleSendForQC(item)}>
                          <Text style={{ color: colors.success, fontWeight: '700' }}>Request QC</Text>
                        </TouchableOpacity>
                      )}
                      <TouchableOpacity style={styles.actionLink} onPress={() => handleDeleteItem(item._id)}>
                        <Text style={{ color: colors.danger, fontWeight: '700' }}>Delete</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                )}
                ListEmptyComponent={<Text style={styles.emptyText}>No inventory items found</Text>}
              />
            )}

            {activeTab === 'shortages' && (
              <FlatList
                data={shortages}
                keyExtractor={(item) => item._id}
                renderItem={({ item }) => (
                  <View style={[styles.card, { borderColor: colors.border }]}>
                    <View style={styles.cardHeader}>
                      <Text style={[styles.cardTitle, { color: colors.text }]}>{item.itemName}</Text>
                      <Text style={{ color: colors.danger, fontWeight: '700' }}>
                        Short: {item.quantity} {item.unit}
                      </Text>
                    </View>
                    <Text style={{ color: colors.textSecondary }}>Assigned To: {item.assignedTo || 'Unassigned'}</Text>
                    {item.remarks ? (
                      <Text style={{ color: colors.textMuted, fontSize: 13 }}>Notes: {item.remarks}</Text>
                    ) : null}
                  </View>
                )}
                ListEmptyComponent={<Text style={styles.emptyText}>No active shortage logs</Text>}
              />
            )}

            {activeTab === 'qc' && (
              <FlatList
                data={qcLogs}
                keyExtractor={(item) => item._id}
                renderItem={({ item }) => (
                  <View style={[styles.card, { borderColor: colors.border }]}>
                    <View style={styles.cardHeader}>
                      <Text style={[styles.cardTitle, { color: colors.text }]}>{item.materialName}</Text>
                      <Text style={[styles.qtyText, { color: colors.primary }]}>
                        {item.quantity} {item.unit}
                      </Text>
                    </View>
                    <Text style={{ color: colors.textSecondary }}>Remarks: {item.remarks || 'No notes.'}</Text>
                    <Text
                      style={[
                        styles.statusText,
                        {
                          color:
                            item.status === 'verified'
                              ? colors.success
                              : item.status === 'pending_verification'
                              ? colors.warning
                              : colors.danger,
                        },
                      ]}
                    >
                      Status: {item.status.toUpperCase().replace('_', ' ')}
                    </Text>
                  </View>
                )}
                ListEmptyComponent={<Text style={styles.emptyText}>No QC check logs found</Text>}
              />
            )}
          </View>
        )}
      </View>

      {/* Stock Edit Modal */}
      <Modal visible={showItemModal} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>
              {editingItemId ? 'Edit Inventory Item' : 'Add Stock Item'}
            </Text>
            <ScrollView keyboardShouldPersistTaps="handled">
              <View style={styles.inputGroup}>
                <Text style={styles.label}>Item Name *</Text>
                <TextInput
                  style={[styles.input, { borderColor: colors.border, color: colors.text }]}
                  placeholder="e.g. Nylon Sheet"
                  value={itemName}
                  onChangeText={setItemName}
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>Type</Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginVertical: 4 }}>
                  {['raw_material', 'finished_good', 'packaging', 'other'].map((type) => (
                    <TouchableOpacity
                      key={type}
                      style={[
                        styles.smallBadge,
                        {
                          backgroundColor: itemType === type ? colors.primary : '#ffffff',
                          borderColor: colors.border,
                          borderWidth: 1,
                        },
                      ]}
                      onPress={() => setItemType(type)}
                    >
                      <Text
                        style={{
                          color: itemType === type ? '#ffffff' : colors.textSecondary,
                          fontSize: 12,
                          fontWeight: '600',
                        }}
                      >
                        {type.replace('_', ' ')}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
              </View>

              <View style={styles.row}>
                <View style={[styles.inputGroup, { flex: 2, marginRight: 8 }]}>
                  <Text style={styles.label}>Quantity *</Text>
                  <TextInput
                    style={[styles.input, { borderColor: colors.border, color: colors.text }]}
                    placeholder="0"
                    value={quantity}
                    onChangeText={setQuantity}
                    keyboardType="numeric"
                  />
                </View>
                <View style={[styles.inputGroup, { flex: 1 }]}>
                  <Text style={styles.label}>Unit</Text>
                  <TextInput
                    style={[styles.input, { borderColor: colors.border, color: colors.text }]}
                    placeholder="kg/pcs"
                    value={unit}
                    onChangeText={setUnit}
                  />
                </View>
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>Godown Location (Rack / Bin)</Text>
                <TextInput
                  style={[styles.input, { borderColor: colors.border, color: colors.text }]}
                  placeholder="e.g. Rack A - Bin 1"
                  value={location}
                  onChangeText={setLocation}
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>Size / Spec (Optional)</Text>
                <TextInput
                  style={[styles.input, { borderColor: colors.border, color: colors.text }]}
                  placeholder="e.g. 50mm x 10m"
                  value={size}
                  onChangeText={setSize}
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>Description</Text>
                <TextInput
                  style={[styles.input, styles.textArea, { borderColor: colors.border, color: colors.text }]}
                  placeholder="Notes about quality or usage..."
                  value={description}
                  onChangeText={setDescription}
                  multiline
                  numberOfLines={2}
                />
              </View>

              <View style={styles.modalButtons}>
                <TouchableOpacity
                  style={[styles.cancelBtn, { borderColor: colors.border }]}
                  onPress={() => setShowItemModal(false)}
                >
                  <Text style={{ color: colors.textSecondary, fontWeight: '600' }}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.submitBtn, { backgroundColor: colors.primary }]}
                  onPress={handleSaveItem}
                  disabled={submitting}
                >
                  {submitting ? (
                    <ActivityIndicator color="#ffffff" />
                  ) : (
                    <Text style={{ color: '#ffffff', fontWeight: '700' }}>Save Stock</Text>
                  )}
                </TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  tabContainer: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    backgroundColor: '#ffffff',
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 14,
  },
  tabText: {
    fontSize: 14,
    fontWeight: '700',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  searchInput: {
    flex: 1,
    borderWidth: 1,
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 12,
    backgroundColor: '#ffffff',
  },
  addButton: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  addButtonText: {
    color: '#ffffff',
    fontWeight: '700',
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    borderWidth: 1,
    padding: 16,
    marginBottom: 12,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: '700',
  },
  qtyText: {
    fontSize: 15,
    fontWeight: '700',
  },
  qcStatus: {
    fontSize: 12,
    fontWeight: '700',
    marginTop: 4,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '700',
    marginTop: 6,
  },
  actionsRow: {
    flexDirection: 'row',
    gap: 16,
    marginTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
    paddingTop: 8,
  },
  actionLink: {
    paddingVertical: 4,
  },
  emptyText: {
    textAlign: 'center',
    marginTop: 40,
    color: '#64748b',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 24,
    maxHeight: '85%',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 16,
    textAlign: 'center',
  },
  inputGroup: {
    marginBottom: 16,
  },
  row: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 8,
    color: '#334155',
  },
  input: {
    borderWidth: 1,
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 12,
    fontSize: 15,
    backgroundColor: '#ffffff',
  },
  smallBadge: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 16,
    marginRight: 8,
  },
  textArea: {
    height: 60,
    textAlignVertical: 'top',
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 16,
  },
  cancelBtn: {
    flex: 1,
    borderWidth: 1,
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: 'center',
  },
  submitBtn: {
    flex: 2,
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: 'center',
  },
});
