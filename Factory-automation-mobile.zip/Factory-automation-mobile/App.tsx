import React from 'react';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AuthProvider } from './src/context/AuthContext';
import { OrgProvider } from './src/context/OrgContext';
import { ThemeProvider } from './src/context/ThemeContext';
import AppNavigator from './src/navigation/AppNavigator';

function App(): React.JSX.Element {
  return (
    <SafeAreaProvider>
      <AuthProvider>
        <OrgProvider>
          <ThemeProvider>
            <AppNavigator />
          </ThemeProvider>
        </OrgProvider>
      </AuthProvider>
    </SafeAreaProvider>
  );
}

export default App;
